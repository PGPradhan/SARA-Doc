cd c:\SARA
python sara_main.py .\Config\sara.yaml --update
