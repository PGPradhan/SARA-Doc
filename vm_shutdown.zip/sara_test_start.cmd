call activate pySARA

cd c:\SARA
python sara_main.py .\Config\test.sara.yaml 
