call activate pySARA

cd c:\SalesAlerts
python salesalerts_main.py .\Config\salesalerts.yaml --autostart



