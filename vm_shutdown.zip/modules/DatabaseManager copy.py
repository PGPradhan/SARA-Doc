import os
import sys
import pandas as pd
import logging
import time
import sqlalchemy
import logging
import utils

class DataDetailsObject(utils.JsonSerializable):
    '''Data container class holding simple values - to be serialized to JSON'''
    def __init__(self):
        '''dynamically add attributes/member variables to instance of this class that need to be serialized to JSON'''
        pass


class DatabaseManager():

    def __init__(self, config):
        self._config = config
        self.result_id = None
        self._db_schema = self._config["database"]["schema"]
        self._logger = logging.getLogger()

    def _create_db_engine(self):
        self._logger.debug("create db engine")
        db_config = self._config["database"]
        if "database.windows.net" in db_config["server"]:
            db_username = "{}@{}".format(db_config["user"], db_config["server"].split('.')[0])
        else: 
            db_username = db_config["user"]

        connection_string = "mssql+pymssql://{}:{}@{}/{}".format(
            db_username,
            db_config["password"], 
            db_config["server"], 
            db_config["dbname"])
        # self._logger.debug("Connectionstring: " + connection_string)
        engine = sqlalchemy.create_engine(connection_string, echo=False)
        self._logger.debug("db engine created.")
        return engine


    def create_result_record(self, model_version):
        '''Create the initial/master result record and retrieve its ID, which is required by foreign-key dependent tables (_write_db_table_XYZ)'''
        engine = self._create_db_engine()
        self._logger.info("Create/open result record, model_version=" + model_version)
        with engine.begin() as conn:  # ContextManager handles transaction
            sql_query = "insert into [{}].[Results] (ModelVersion, StartTimeUtc) values ('{}', GETUTCDATE()); SELECT SCOPE_IDENTITY()".format(self._db_schema, model_version)	
            self._logger.info("Execute sql query: " + sql_query)
            data_row = conn.execute(sql_query).fetchone()
            self.result_id = int(data_row[0])

            self._logger.info("Created result record.")
            self._logger.debug("id=" + str(self.result_id))


    def quote_Nonable_for_db(self, value):
        if value is None:
            return 'Null'
        else:
            return "'{}'".format(value)

    def close_result_record(self, result_status, result_details=None, error_details=None):
        if self.result_id is None:
            self._logger.error("Cannot close result record: ResultId is not available.")
            return 

        engine = self._create_db_engine()
        self._logger.info("Close result record")
        with engine.begin() as conn:  # begin uses ContextManager which handles transaction
            sql_query = "update [{}].[Results] set ResultStatus='{}', EndTimeUtc=GETUTCDATE(), ResultDetailsJson={}, ErrorDetailsJson={} where ResultId={}".format(self._db_schema, result_status, self.quote_Nonable_for_db(result_details), self.quote_Nonable_for_db(error_details), self.result_id)
            self._logger.info("Execute sql query: " + sql_query[0:100] + "...")
            conn.execute(sql_query)
            self._logger.info("Close/update result table")


    def _truncate_db_table(self, table_name):
        self._logger.info("Truncate DB table: %s", table_name)
        engine = self._create_db_engine()
        with engine.begin() as conn:  # begin uses ContextManager which handles transaction
            sql_query = "truncate table [{}].[{}]".format(self._db_schema, table_name)
            self._logger.info("Execute sql query: " + sql_query[0:100] + "...")
            conn.execute(sql_query)
            self._logger.info("DB table %s truncated successfully.", table_name)


    def get_latest_model_version(self, model_version_base):
        '''query database for models with same date'''
        self._logger.info("Get previous model versions (same base model)")
        engine = self._create_db_engine()
        sql_query = "Select ModelVersion from [{}].[Results] where ModelVersion like '{}.%' order by ModelVersion desc".format(self._db_schema, model_version_base)
        self._logger.debug("connect")
        with engine.connect() as conn:  
            self._logger.debug("execute query: %s", sql_query)
            latest_model_version = conn.execute(sql_query).fetchone()
            if latest_model_version is not None:
                latest_model_version = str(latest_model_version[0])
            self._logger.info("Got latest model version: ")
            self._logger.info(latest_model_version)
        return latest_model_version

    def read_db_salesorderitems(self):
        self._logger.info("read sales items from database table 'CrmSalesOrderItems'")
        engine = self._create_db_engine()
        with engine.connect() as conn:
            sql_query = "SELECT [SalesOrderDateTime], [CustomerId], [SalesOrderId], [ProductId], [NetValue] from [{}].[CrmSalesOrderItems]".format(self._db_schema)
            self._logger.debug("execute query: %s", sql_query)
            df_salesorderitems = pd.read_sql_query(sql_query, conn) 
        print("Fetch complete, #salesorderitems: %d", len(df_salesorderitems))
        return df_salesorderitems


    def _write_db_table(self, db_tablename, dataframe):
        try:
            self._logger.info("write db table")
            chunksize = self._config["database"]["chunksize"]

            start_time = time.time()
            df_extended = dataframe.copy()
            df_extended["ResultId"] = [self.result_id] * len(dataframe)  # add foreign-key reference

            engine = self._create_db_engine()
            self._logger.info("Begin transaction")
            with engine.begin() as conn:  # begin uses ContextManager which handles transaction
                self._logger.info("Write dataframe to db table: " + db_tablename)
                df_extended.to_sql(db_tablename, conn, schema=self._db_schema, index=False, if_exists='append', chunksize=chunksize)
            self._logger.info("Table written to database, duration={}s".format(time.time()-start_time))

        except:
            self._logger.error("Failed to write database table: %s", db_tablename)
            self._logger.error(sys.exc_info())

    def write_db_table_peergroups(self, dataframe) :
        self._write_db_table("PeerGroups", dataframe)

    def write_db_table_peergroupproductgroups(self, dataframe) :
        self._write_db_table("PeerGroupProductGroups", dataframe)

    def write_db_table_recommendations(self, dataframe) :
        self._write_db_table("RecommendationCandidates", dataframe)

    def write_db_table_customerproductgroupsellings(self, dataframe) :
        self._write_db_table("CustomerProductGroupSellings", dataframe)

    def truncate_db_table_recommendations(self) :
        self._truncate_db_table("RecommendationCandidates")

