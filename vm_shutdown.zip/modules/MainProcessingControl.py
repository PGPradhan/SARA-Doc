import sys
import os
import io
import yaml
import argparse
import logging
import pandas as pd
import logging
import datetime
import traceback
from DataPreprocessing import DataPreProcessing
from SaraClusteringAndRecommendation import SaraRecommendations
from DatabaseManager import DatabaseManager, DataDetailsObject
from CrmManager import CrmManager
import LoggingHelper
import utils



class MainProcessingControl():

    def __init__(self, config):

        # members
        self._config = config
        self._clustering_control = None
        self._model_version = None

        self._logger = logging.getLogger()

        self._db_manager = DatabaseManager(self._config)
        self._crm_manager = CrmManager(self._config)
        self._data_preprocessing = DataPreProcessing(self._config)


    def _init_model_version(self) :
        '''
            Create a model version identifier: format=YYYY-MM-DD.NNN  e.g. 2018-07-23.001 
            NNN is an ongoining run count on the same day.
            Query database for models with same date, increase the subversion count 
            on the most recent entry: eg. 2018-07-23.002, 2018-07-23.003, ...

            In production actually only one run should happen per day (at least for the time being)
        '''

        self._logger.info("init model version)")
        model_version_base = datetime.datetime.now().strftime("%Y-%m-%d")
        latest_model_version = self._db_manager.get_latest_model_version(model_version_base)
        if latest_model_version is None: 
            self._model_version = model_version_base + ".001"
        else:
            (_, latest_model_subversion) = latest_model_version.split('.')
            self._model_version = model_version_base + "." + str(int(latest_model_subversion)+1).zfill(3)


    def _clean_target_data(self):
        for node in ["output"]:
            try:
                work_dir = self._config[node]["path"]
                for filename in os.listdir(work_dir):
                    if filename.endswith(".csv"):
                        self._remove_file(os.path.join(work_dir, filename))
            except:
                self._logger.error("Failed")


    def _remove_file(self, filename_with_path):
        try:
            os.remove(filename_with_path)
        except:
            self._logger.error("Failed to remove file:" + filename_with_path)


    def _prepare_output_data(self):
        self._logger.info("gather output data")

        # gather general details/statistics
        self._logger.info("gather result/data details")
        result_details = self._data_preprocessing.get_statistics()
        result_details.CountPeerGroups = self._clustering_control.nof_peergroups

        if self._is_workflow_step_enabled("clustering"):
            self._logger.info("Recommendations as from clusterings")
            self._logger.data(self._clustering_control.recommendation_data.head())

            self._logger.info("customer to peergroup mapping")
            self._logger.data(self._clustering_control.customer_cluster_mapping.head())

            self._logger.info("top Sara product groups in peergroup")
            self._logger.data(self._clustering_control.top_groups_with_values.head())

            result_details.CountRecommendations = len(self._clustering_control.recommendation_data)

        # map config keys to respective data tables: output node key, dataframe, audit store func
        output_data = [
            ("recommendations", self._clustering_control.recommendation_data, self._db_manager.write_db_table_recommendations)
        ]

        # auxiliary table for analytics - write only when needed
        if self._config["output"]["write_aux_db_tables"] is True:
            output_data.extend([
                ("cust_peergroups", self._clustering_control.customer_cluster_mapping, self._db_manager.write_db_table_peergroups), 
                ("peergroup_spgs", self._clustering_control.top_groups_with_values, self._db_manager.write_db_table_peergroupproductgroups),
                ("cust_spg_sellings", self._data_preprocessing.df_customer_spg_netsales, self._db_manager.write_db_table_customerproductgroupsellings)
            ])
        else:
            self._logger.info("Writing of auxilliary analytics tables is skipped.")
            
        return (output_data, result_details)



    def _store_crm_output_data(self, output_data):
        self._logger.info("store output data for SARA.NET")

        output_node = self._config["output"]

        output_data_path = output_node["path"]
        if not os.path.exists(output_data_path):
            os.makedirs(output_data_path, exist_ok=True)

        for key, df, _ in output_data:
            if key in output_node:
                df_filename = os.path.join(output_data_path, output_node[key])
                self._logger.info("save output data file:" + df_filename)
                df.to_csv(df_filename, encoding="utf-8")


    def _write_results_to_db(self, output_data):
        self._logger.info("store audit data")

        # keep recommendations from old runs? If not then empty table before upload
        if self._config["output"]["keep_recommendations"] is False:
            self._db_manager.truncate_db_table_recommendations()

        for key, df, write_db_table_func in output_data:
            write_db_table_func(df)


    def update_auxiliary_tables(self):
        self._data_preprocessing = DataPreProcessing(self._config)
        self._data_preprocessing.update_auxiliary_tables()


    def run_workflow(self):
        '''runs the main clustering workflow including data retrieval from CRM, peergroup clustering and result storage in CRM'''
        try:
            self._logger.info("Start main workflow")
            start_time = datetime.datetime.now()

            self._init_model_version()
            self._db_manager.create_result_record(self._model_version)

            if self._is_workflow_step_enabled("crm-fetch"):
                self._logger.info("Clean old data")
                self._clean_target_data()

                self._logger.info("Fetch data from CRM")
                self._crm_manager.fetch_data_from_crm()

            df_salesorderitems = None
            if self._is_workflow_step_enabled("db-fetch"):
                self._logger.info("Fetch sales order data from database")
                df_salesorderitems = self._db_manager.read_db_salesorderitems()

            self._logger.info("Preprocess input data")
            self._data_preprocessing.process_data(df_salesorderitems)
        
            self._logger.info("Init clustering")
            self._clustering_control = SaraRecommendations(self._config)
            if self._is_workflow_step_enabled("clustering"):
                step_start_time = datetime.datetime.now()
                self._logger.info("Perform peergroup clustering")
                self._clustering_control.perform_peer_group_clustering(self._data_preprocessing.df_sara_data)

                self._logger.info("Compute recommendations and auxiliary statistics")
                self._logger.debug("calculate recommendations")
                self._clustering_control.calculate_recommendations()
                self._logger.debug("list groups in cluster")
                self._clustering_control.list_groups_in_cluster()
                self._logger.debug("collect customer cluster mapping")
                self._clustering_control.collect_customer_cluster_mapping()
                self._logger.info("Clustering completed successfully, duration=%ds", (datetime.datetime.now()-step_start_time).total_seconds())

            self._logger.info("Gather output data")
            output_data, result_details = self._prepare_output_data()
            self._store_crm_output_data(output_data)
            
            if self._is_workflow_step_enabled("db-write"):
                self._write_results_to_db(output_data)

            if self._is_workflow_step_enabled("crm-write"):
                self._logger.info("Write result recommendation records to CRM")
                self._crm_manager.write_results_to_crm(self._db_manager.result_id)

            self._logger.info("Write final result status to db")
            self._db_manager.close_result_record("Ok", result_details=result_details)

            self._logger.info("Finished successfully, duration=%ds", (datetime.datetime.now()-start_time).total_seconds())

        except:
            self._handle_critical_exception()


    def _handle_critical_exception(self):
        try:
            self._logger.critical("CRITICAL error occurred")
            error_details = DataDetailsObject()
            ex_type, ex_value, ex_traceback = sys.exc_info()
            self._logger.critical("Exception: type=%s", str(ex_type))
            self._logger.critical("Exception: value=%s", str(ex_value))
            self._logger.critical("Exception: traceback=%s", str(ex_traceback))

            error_details.ErrorMessage = str(ex_value).replace('"', "´´").replace("'", "´")
            error_details.Log = LoggingHelper.load_log_file(self._config).replace('"', "´´").replace("'", "´")
            print("Critical error: ", error_details.ErrorMessage)
            self._logger.critical(traceback.format_exc())
            self._db_manager.close_result_record("Error", error_details=error_details)
        except:
            logging.critical("Critical failure... abort execution.")
            logging.critical(traceback.format_exc())


    def _is_workflow_step_enabled(self, step_name):
        '''disable certain steps for testing/debugging purposes'''

        # disableable steps: crm-fetch, db-fetch, db-write, crm-write
        disabled_steps = self._config["maintenance"]["disabled_workflow_steps"]
        if step_name in disabled_steps:
            self._logger.warn("Step [%s] is disabled !", step_name)
            self._logger.warn("List of disabled steps: [%s]", " ".join(disabled_steps)) 
            return False
        return True
