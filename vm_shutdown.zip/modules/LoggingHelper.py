import sys
import os
import yaml
import time
import logging
from logging.handlers import TimedRotatingFileHandler

DATA_LEVEL_NUM = 5
FALLBACK_LOG = './fatal.log'


def data(self, message, *args, **kws):
    # Yes, logger takes its '*args' as 'args'.
    if self.isEnabledFor(DATA_LEVEL_NUM):
        self._log(DATA_LEVEL_NUM, "", args, **kws) 
        self._log(DATA_LEVEL_NUM, message, args, **kws) 
        self._log(DATA_LEVEL_NUM, "", args, **kws) 


def add_data_level():
    logging.addLevelName(DATA_LEVEL_NUM, "DATA")
    logging.Logger.data = data
    logging.data = data
    logging.DATA = DATA_LEVEL_NUM

def clean_old_fallback_logs():
    try:
        if os.path.exists(FALLBACK_LOG):
            os.remove(FALLBACK_LOG)
    except:
        pass

def init_fallback_logging():
    try:
        print("failed to initialize regular logging")
        add_data_level()
        #logging_format = '%(asctime)s %(levelname)-8s %(module)-25s %(message)s'
        logging.basicConfig(filename=FALLBACK_LOG, level=logging.DEBUG, format=LevelFormatter.default_logging_format, filemode='w') # overwrite
        logging.info("Could not initialize regular log. Using fallback log %s instead.", FALLBACK_LOG)
    except:
        pass


def init_logging(yaml_config_file):
    clean_old_fallback_logs()

    try:
        with open(yaml_config_file, "r") as fp:
            log_config = yaml.safe_load(fp)["logging"]

        log_path = log_config["path"]
        log_file = log_config["logfile"]
        log_level_str = log_config["loglevel"].upper()

        if not os.path.exists(log_path):
            os.mkdir(log_path)
        add_data_level()
        log_file = os.path.join(log_path, log_file)    
        log_level = logging.getLevelName(log_level_str) # undocumented feature of this method
        #logging.basicConfig(filename=log_file, level=log_level, filemode='w') # overwrite
        logging.basicConfig(level=log_level, filemode='a') # overwrite

        logger = logging.getLogger()
        logger.addHandler(TimedRotatingFileHandler(log_file, when="midnight", backupCount=log_config["max_roll_backups"]))
       
        for i in range(len(logger.handlers)):
            logger.handlers[i].setFormatter(LevelFormatter())
        logger.log(100, "") # log always
        logger.log(100, "logging initialized.") # log always
        logger.log(100, "") # log always

    except:
        print(sys.exc_info())
        init_fallback_logging()


def load_log_file(config):
    try:
        log_file = os.path.join(config["logging"]["path"], config["logging"]["logfile"])    
        with open(log_file, "r") as fp:
            log_content = fp.read()
        return log_content
    except:
        return ""


class LevelFormatter(logging.Formatter):
    
    default_logging_format = '%(asctime)s %(levelname)8s %(module)-25s %(funcName)-25s  %(message)s'
    default_formatter = logging.Formatter(default_logging_format)
    data_formatter = logging.Formatter(r'%(message)s')

    def format(self, record):
        if record.levelno >= 100: # always
            return self.data_formatter.format(record)
        elif record.levelno == logging.DATA:
            return self.data_formatter.format(record)
        else:
            return self.default_formatter.format(record)