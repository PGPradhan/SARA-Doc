import sys
sys.path.append("./modules")

import os
import io
import numpy as np
import pandas as pd
import logging
import time
import utils
import yaml
from ProductGroupMappings import ProductGroupMappings
from DatabaseManager import DataDetailsObject


class DataPreProcessing():

    def __init__(self, config):
        self._config = config
        self._logger = logging.getLogger()

        # keep data for auditing
        self.df_salesorderitems = None
        self.df_customer_spg_netsales = None
        self.df_sara_data = None
        self.auxiliary_tables = ProductGroupMappings(config)



    def update_auxiliary_tables(self):
        self.auxiliary_tables.create_auxiliary_tables()


    def get_statistics(self) :
        data_details = DataDetailsObject()
        self._logger.debug("get_statistics")
        if self.df_salesorderitems is not None:
            data_details.DataWindowStartTime = self.df_salesorderitems["SalesOrderDateTime"].dropna().min()
            data_details.DataWindowEndTime = self.df_salesorderitems["SalesOrderDateTime"].dropna().max()
            data_details.CountSalesOrderItems = len(self.df_salesorderitems)
            data_details.CountProductGroups = self.df_salesorderitems["ProductGroup"].nunique()
            data_details.CountSaraProductGroups = self.df_salesorderitems["SaraProductGroup"].nunique()
            data_details.CountCustomers = self.df_salesorderitems["CustomerId"].nunique()
            data_details.SumNetValue = self.df_salesorderitems["NetValue"].sum()
        self._logger.debug("get_statistics - done")
        return data_details

    def load_salesorderitems_from_file(self):
        input_data_path = self._config["input"]["path"]
        input_data_file = self._config["input"]["salesorderitems"]
        input_data_file = os.path.join(input_data_path, input_data_file)

        # load raw sales data from file
        self._logger.info("Load sales order items from file: " + input_data_file)
        self.df_salesorderitems = pd.read_csv(input_data_file, encoding="utf-8")

    def save_salesorderitems_to_file(self):
        output_data_path = self._config["input"]["path"]
        output_data_file = self._config["input"]["salesorderitems"]
        output_data_file = os.path.join(output_data_path, output_data_file)

        # load raw sales data from file
        self._logger.info("Save sales order items to file: " + output_data_file)
        self.df_salesorderitems.to_csv(output_data_file, encoding="utf-8")


    def process_data(self, df_salesorderitems = None):

        # load product to Sara-ProductGroup mappings
        self.auxiliary_tables.load_or_create_auxiliary_tables()
        df_sara_map = self.auxiliary_tables.df_prd_spg_map
        self._logger.data(df_sara_map.head())
        self._logger.debug("Sara product group mapping table loaded, len=%d", len(df_sara_map))

        # load raw sales
        if df_salesorderitems is None:
            self.load_salesorderitems_from_file()
        else:
            self.df_salesorderitems = df_salesorderitems
            self.save_salesorderitems_to_file()

        self.df_salesorderitems["CustomerId"] = self.df_salesorderitems["CustomerId"].astype(str) 
        self._logger.data(self.df_salesorderitems.describe())
        self._logger.data(self.df_salesorderitems.head())
        self._logger.info("count values: %d, sum net value: %f", len(self.df_salesorderitems), self.df_salesorderitems["NetValue"].sum()) 

        # map products to Sara-ProductGroups
        self._logger.info("Apply Sara product group mapping")
        len_before_map = len(self.df_salesorderitems)
        self.df_salesorderitems = self.df_salesorderitems.merge(df_sara_map, on="ProductId")
        len_after_map = len(self.df_salesorderitems)
        self._logger.info("count values: %d, sum net value: %f", len_after_map, self.df_salesorderitems["NetValue"].sum()) 

        if len_after_map < 0.8 * len_before_map:
            self._logger.warn("High number of sales order items could not be mapped to Sara product groups. Check mapping tables !")

        self._logger.debug("Sales data - after mapping of Sara product groups. Columns:")
        self._logger.debug(self.df_salesorderitems.columns)

        self._logger.data(self.df_salesorderitems.head())
        self._logger.info("Mapping of product to Sara product groups done.")

        # aggregate/sum net value per customer and Sara-PG 
        self._logger.info("Aggragate sellings per customer and SaraProductGroup")
        self.df_customer_spg_netsales = self.df_salesorderitems.groupby(['CustomerId', 'SaraProductGroup'], as_index=False)['NetValue'].sum()
        self._logger.data(self.df_customer_spg_netsales.describe())
        self.df_customer_spg_netsales.rename(columns={"NetValue" : "SumNetValue"}, inplace=True)
        self.df_customer_spg_netsales["CustomerId"] = self.df_customer_spg_netsales["CustomerId"].astype(str) 
        self._logger.data(self.df_customer_spg_netsales.head())
        self._logger.info("Groupby by customer and Sara-PG completed.")

        # pivot Sara-PG rows to columns
        df_sara_abs = self.df_customer_spg_netsales.pivot(index='CustomerId', columns='SaraProductGroup', values='SumNetValue').fillna(0.0)
        self._logger.info("Pivot complete. Columns:")

        # determine max sales value per customer (rows) and Sara-PG (columns)
        cust_max_sales = df_sara_abs.max(axis=1)

        # normalizate by max sales values ('Max-Norm')
        self.df_sara_data = df_sara_abs.divide(cust_max_sales, axis=0).fillna(0.0)

        self._logger.info("Normalization completed")
        self._logger.data(self.df_sara_data.head())



# test
if __name__ == "__main__":
    print("run test")
    logging_format = '%(asctime)s  %(message)s'
    self._logger.basicConfig(stream=sys.stdout, level=self._logger.DEBUG, format=logging_format, filemode='w') # overwrite
 
    with io.open("../config/sara.yaml", mode='r', encoding="utf-8") as fp:
        config = yaml.load(fp)
    print(config)

    dp = DataPreProcessing(config)
    dp.process_data()
    