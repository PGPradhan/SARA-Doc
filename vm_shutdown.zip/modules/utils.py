import io
import subprocess
import logging
import json



def call_sync_external_executable(executable_name, *cmdline_args_as_list):
    logging.info("Run external process: %s %s", executable_name, " ".join(cmdline_args_as_list))
    completed_process_result = subprocess.run([executable_name] + list(cmdline_args_as_list))
    logging.info("External process completed, exit code=%d", completed_process_result.returncode)
    logging.info(completed_process_result.stdout)
    if completed_process_result.returncode != 0:
        logging.error(completed_process_result.stderr)
    completed_process_result.check_returncode() # raises exception if process has exit code other than 0


class JsonSerializable(object):
    def toJson(self):
        return json.dumps(self.__dict__, sort_keys=True, skipkeys=True, default=str)

    def __repr__(self):
        return self.toJson()


