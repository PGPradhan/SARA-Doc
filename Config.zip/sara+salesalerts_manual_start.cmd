call activate py35

cd c:\SalesAlerts
python salesalerts_main.py .\Config\salesalerts.yaml

cd c:\SARA
python sara_main.py .\Config\sara.yaml

