import sys
import os
import time
import modules.utils as utils

from modules.LoggingHelper import get_logger

class CrmManager():

    yaml_config_file = None

    def __init__(self, config):
        self._config = config

        self._crm_connector_exe = r".\DataTool\SaraDataTool.exe"
        # Usage: SalesAlertsDataTool Tasks=OrderItemsToSql,SalesAlertCandidatesToCrm"

        self._max_repetitions_on_error = self._config.crm.max_repetitions_on_error
        self._repetition_delay_on_error_seconds =  self._config.crm.repetition_delay_on_error_seconds

        self._logger = get_logger()


    def _run_crm_connector(self, *args):
        for i in range(self._max_repetitions_on_error+1):
            try: 
                utils.call_sync_external_executable(self._crm_connector_exe, *args)  # throws exception
                return
            except:
                self._logger.error(sys.exc_info())
                self._logger.info("Wait some time before trying to repeat...")
                time.sleep(self._repetition_delay_on_error_seconds)
                self._logger.info("Repeat [%d]", i+1)
        self._logger.critical('Failed to write results to CRM')
        raise RuntimeError('Failed to write results to CRM')

    def fetch_data_from_crm(self):
        self._logger.info("fetch data from CRM")
        self._run_crm_connector("ConfigFile=" + os.path.abspath(CrmManager.yaml_config_file), "Tasks=OrdersCrmToSql")


    def write_results_to_crm(self, result_id):
        self._logger.info("fetch feedbacks from CRM")
        self._run_crm_connector("ConfigFile=" + os.path.abspath(CrmManager.yaml_config_file), "Tasks=SalesAlertFeedbacksToSql")
        self._logger.info("write results to CRM")
        self._run_crm_connector("ConfigFile=" + os.path.abspath(CrmManager.yaml_config_file), "Tasks=SalesAlertsToCrm", "ResultId={}".format(result_id))