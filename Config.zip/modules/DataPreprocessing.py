import sys
import os
import io
import pandas as pd
import yaml
import traceback
import datetime
from pytz import timezone 

from modules.DatabaseManager import DataDetailsObject
from modules.LoggingHelper import get_logger


class DataPreProcessing():

    def __init__(self, config):
        self._config = config
        self._logger = get_logger()

        # raw input data
        self.df_salesorders = None

        # pre-processed/filtered data: input to actual SalesAlerts computation
        self.df_salesorders_filtered = None
        self.customers = None
        self.max_orders = None
        self.min_orders = None
        self.relevant_ordertypes = None
        self.df_passed_days_orders = None


    def get_statistics(self) :
        data_details = DataDetailsObject()
        self._logger.debug("get_statistics")
        if self.df_salesorders is not None:

            timestamps = self.df_salesorders_filtered["OrderDateTime"].dropna()
            data_details.DataWindowStartTime = timestamps.min()
            data_details.DataWindowEndTime = timestamps.max()
            data_details.CountSalesOrdersTotal = len(self.df_salesorders)
            data_details.CountSalesOrdersFiltered = len(self.df_salesorders_filtered)
            data_details.CountCustomersTotal = self.df_salesorders["CustomerId"].nunique()
            data_details.CountCustomersFiltered = self.df_salesorders_filtered["CustomerId"].nunique()
            # t.b.d  maybe further numbers...  

        self._logger.debug("get_statistics - done")
        return data_details

    def load_salesorders_from_file(self):
        '''
            Load raw data from file: 
                - only for development to skip CRM and DB fetch
        '''
        input_data_path = self._config.input.path
        input_data_file = self._config.input.salesorders
        input_data_file = os.path.join(input_data_path, input_data_file)

        # load raw sales data from file
        self._logger.info("Load sales order items from file: " + input_data_file)
        self.df_salesorders = pd.read_csv(input_data_file, encoding="utf-8", sep=',', header='infer')


    def save_salesorders_to_file(self):
        '''
            Store raw data in file for debugging / development purposes
        '''
        try: 
            output_data_path = self._config.input.path
            output_data_file = self._config.input.salesorders
            output_data_file = os.path.join(output_data_path, output_data_file)

            # load raw sales data from file
            self._logger.info("Save sales order items to file: " + output_data_file)
            self.df_salesorders.to_csv(output_data_file, encoding="utf-8")
        except Exception as ex:
            self._logger.error("Failed to save data to file.")
            self._logger.error(traceback.format_exc())


    def process_data(self, df_salesorders = None):

        self._logger.info("Initialization of data preprocess")

        # load raw sales
        if df_salesorders is None:
            self.load_salesorders_from_file()
        else:
            self.df_salesorders = df_salesorders
            self.save_salesorders_to_file()

        self._logger.info("Count values of raw data: {}".format(len(self.df_salesorders)))
        self.df_salesorders = self.df_salesorders.dropna(subset = ["CustomerId", "OrderDateTime"])
        self.df_salesorders["CustomerId"] = self.df_salesorders["CustomerId"].astype(str)
        self.df_salesorders["SalesOfficeId"] = self.df_salesorders["SalesOfficeId"].astype(str)
        self.df_salesorders['OrderDateTime'] = pd.to_datetime(self.df_salesorders['OrderDateTime'], errors='coerce')
        self._logger.debug(self.df_salesorders.describe())
        self._logger.debug(self.df_salesorders.head())
        self._logger.info("count values: {}".format(len(self.df_salesorders)))

        if len(self.df_salesorders) <= 0:
            raise ValueError("Dataframe is empty. No data received") 

        # Filter / exclude future OrderDateTime
        self._logger.debug("Exclution of invalid dates")
        #A = datetime.date(2019,12,15)
        self.df_salesorders = self.df_salesorders[self.df_salesorders['OrderDateTime'].notna()]
        #self.df_salesorders = self.df_salesorders[self.df_salesorders['OrderDateTime'] <= A]
        self.df_salesorders = self.df_salesorders[self.df_salesorders['OrderDateTime'] <= datetime.datetime.today()]
        # convert datetime into datetime and timezone
        lst_dt = []
        self.timezone = self._config.SalesAlert.filter.timezone
        for dt in self.df_salesorders.OrderDateTime:
            lst_dt.append(timezone('UTC').localize(dt).astimezone(timezone(self.timezone)))
        self.df_salesorders['OrderDateTime_Timezone'] = lst_dt

        self.df_salesorders['OrderDate'] = self.df_salesorders['OrderDateTime_Timezone'].dt.date
        
        self._logger.info("Number of customers: {}".format(len(self.df_salesorders["CustomerId"].unique())))
        self._logger.info("Number of Orders: {}".format(len(self.df_salesorders)))

        # Filter orders by OrderType
        
        if "OrderType" in self.df_salesorders.columns:
            self._logger.debug("Filter orders by OrderType")
            self.relevant_ordertypes = self._config.SalesAlert.filter.list_of_bills
            self.df_salesorders = self.df_salesorders[self.df_salesorders['OrderType'].isin(self.relevant_ordertypes)]
            self.df_salesorders = self.df_salesorders.drop("OrderType", axis=1)

        self._logger.info("Number of customers: {}".format(len(self.df_salesorders["CustomerId"].unique())))
        self._logger.info("Number of Orders: {}".format(len(self.df_salesorders)))

        # Filter orders by orders within last year
        self._logger.debug("Filter orders by orders within last year")
        timewindow = self._config.SalesAlert.filter.timewindow
        #filter_date = A - datetime.timedelta(days=timewindow)
        filter_date = datetime.date.today() - datetime.timedelta(days=timewindow)
        self.df_salesorders = self.df_salesorders[self.df_salesorders.OrderDate > filter_date]

        self._logger.info("Number of customers: {}".format(len(self.df_salesorders["CustomerId"].unique())))
        self._logger.info("Number of Orders: {}".format(len(self.df_salesorders)))

        # Filter / Remove orders of the same day
        self._logger.debug("Filter multiple orders per day")
        self.df_salesorders = self.df_salesorders.drop_duplicates(subset=["CustomerId","OrderDate"], keep='first')
        

        self._logger.info("Number of customers: {}".format(len(self.df_salesorders["CustomerId"].unique())))
        self._logger.info("Number of Orders: {}".format(len(self.df_salesorders)))       

        # Filter customers by orders per year
        self._logger.debug("Filter customers by orders per year")
        no_of_orders_pa = self._config.SalesAlert.filter.no_of_orders_pa
        customers_grouped = self.df_salesorders.groupby("CustomerId").count()
        self.customers = sorted(list(customers_grouped.index[customers_grouped.OrderDate >= no_of_orders_pa]))
        self.df_salesorders_filtered = self.df_salesorders[self.df_salesorders['CustomerId'].isin(self.customers)]

        self._logger.info("Number of customers: {}".format(len(self.df_salesorders_filtered["CustomerId"].unique())))
        self._logger.info("Number of Orders: {}".format(len(self.df_salesorders_filtered)))





        self._logger.info("Data preprocessing completed")
        self._logger.debug(self.df_salesorders_filtered.head())



# test
if __name__ == "__main__":
    print("run test")
    logging_format = '%(asctime)s  %(message)s'
    self._logger.basicConfig(stream=sys.stdout, level=self._logger.DEBUG, format=logging_format, filemode='w') # overwrite
 
    with io.open("../config/salesalerts.yaml", mode='r', encoding="utf-8") as fp:
        config = yaml.safe_load(fp)
    print(config)

    dp = DataPreProcessing(config)
    dp.process_data()
    