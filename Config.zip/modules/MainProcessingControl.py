import sys
import os
import logging
import pandas as pd
import logging
import datetime
import traceback
from modules.DataPreprocessing import DataPreProcessing
from modules.SalesAlerts import SalesAlerts
from modules.DatabaseManager import DatabaseManager, DataDetailsObject
from modules.CrmManager import CrmManager
import modules.utils as utils

from modules.LoggingHelper import get_logger

class MainProcessingControl():

    def __init__(self, config):

        # members
        self._config = config
        self._salesalerts_control = None
        self._model_version = None

        self._logger = get_logger()

        self._db_manager = DatabaseManager(self._config)
        self._crm_manager = CrmManager(self._config)
        self._data_preprocessing = DataPreProcessing(self._config)

        self._output_data = None
        self._result_details = None


    def _init_model_version(self) :
        '''
            Create a model version identifier: format=YYYY-MM-DD.NNN  e.g. 2018-07-23.001 
                - NNN is an ongoining run count on the same day.
                - Query database for models with same date then increase the last run count by 1 
                    e.g. on the most recent entry: eg. 2018-07-23.002, 2018-07-23.003, ...

            In production actually only one run should happen per day (at least for the time being)
        '''

        self._logger.info("init model version)")
        model_version_base = datetime.datetime.now().strftime("%Y-%m-%d")
        latest_model_version = self._db_manager.get_latest_model_version(model_version_base)
        if latest_model_version is None: 
            self._model_version = model_version_base + ".001"  # first run on a day
        else:
            (_, latest_model_subversion) = latest_model_version.split('.')
            self._model_version = model_version_base + "." + str(int(latest_model_subversion)+1).zfill(3)  # increase run count and format


    def _clean_target_data(self):
        try:
            work_dir = self._config.output.path
            for filename in os.listdir(work_dir):
                if filename.endswith(".csv"):
                    self._remove_file(os.path.join(work_dir, filename))
        except:
            self._logger.error("Failed")


    def _remove_file(self, filename_with_path):
        try:
            os.remove(filename_with_path)
        except:
            self._logger.error("Failed to remove file:" + filename_with_path)


    def _prepare_output_data(self):
        self._logger.info("gather output data")

        # gather general details/statistics
        self._logger.info("gather result/data details")
        self._result_details = self._data_preprocessing.get_statistics()
        self._result_details.CountSalesAlerts = self._salesalerts_control.nof_salesalerts
        self._result_details.IsDisabledTimeFrame = self._salesalerts_control.IsDisabledTimeFrame

        self._logger.info("Sales alerts")
        self._logger.debug(self._salesalerts_control.df_salesalerts.head())

        # map config keys to respective data tables: output node key, dataframe, audit store func
        self._output_data = [
            ("salesalerts", self._salesalerts_control.df_salesalerts, self._db_manager.write_db_table_salesalerts),
        ]


    def _save_output_data_to_files(self):
        try:
            self._logger.info("save output data to files")

            output_node = self._config["output"]

            output_data_path = self._config.output.path
            if not os.path.exists(output_data_path):
                os.makedirs(output_data_path, exist_ok=True)

            for key, df, _ in self._output_data:
                if key in output_node:
                    df_filename = os.path.join(output_data_path, output_node[key])
                    self._logger.info("save output data file:" + df_filename)
                    df.to_csv(df_filename, encoding="utf-8")

        except Exception as ex:
            # catch exception locally - outcome of method is uncritical for overall workflow 
            self._logger.error("Failed to save files.")
            self._logger.error(traceback.format_exc())


    def _write_results_to_db(self):
        self._logger.info("store audit data")
        for key, df, write_db_table_func in self._output_data:
            write_db_table_func(df)


    def run_workflow(self):
        '''
            runs the main clustering workflow including data retrieval from CRM, preprocessing and result storage in CRM
        '''
        try:
            self._logger.info("Start main workflow")
            start_time = datetime.datetime.now()

            if disabled_steps := self._config["maintenance"]["disabled_workflow_steps"]:
                self._logger.warning("Some steps are disabled: [%r]", disabled_steps)

            self._init_model_version()
            self._db_manager.create_result_record(self._model_version)

            if self._is_workflow_step_enabled("crm-fetch"):
                self._logger.info("Clean old data")
                self._clean_target_data()

                self._logger.info("Fetch data from CRM")
                self._crm_manager.fetch_data_from_crm()

            df_salesorders = None
            if self._is_workflow_step_enabled("db-fetch"):
                self._logger.info("Fetch sales order data from database")
                df_salesorders = self._db_manager.read_db_salesorders()

            self._logger.info("Preprocess input data")
            self._data_preprocessing.process_data(df_salesorders)

            self._logger.info("Init calculating of past days between two orders")
            self._salesalerts_control = SalesAlerts(self._config)
            self._salesalerts_control.calc_passed_days(self._data_preprocessing.df_salesorders_filtered, self._data_preprocessing.customers)

            step_start_time = datetime.datetime.now()
            self._salesalerts_control.init_AIRule(self._data_preprocessing.customers, self._salesalerts_control.df_passed_days_orders)
            
            self._logger.info("Check Customer Orders for exceedings")
            self._logger.debug("calculate exceedance")
            self._salesalerts_control.check_exceedance(self._data_preprocessing.df_salesorders_filtered, self._salesalerts_control.df_passed_days_orders, self._data_preprocessing.customers)
            self._logger.info("Sales alerts computed successfully, duration=%ds", (datetime.datetime.now()-step_start_time).total_seconds())

            self._logger.info("Gather and store output data")
            self._prepare_output_data()

            self._logger.info("Store results also locally for analyis purposes")
            self._save_output_data_to_files()
            
            if self._is_workflow_step_enabled("db-write"):
                self._write_results_to_db()

            if self._is_workflow_step_enabled("crm-write"):
                self._logger.info("Write result sales alert records to CRM")
                self._crm_manager.write_results_to_crm(self._db_manager.result_id)

            self._logger.info("Workflow completed successfully. Write final 'Ok' result status to db")
            self._db_manager.close_result_record("Ok", result_details=self._result_details)

            self._logger.info("Finished successfully, duration=%ds", (datetime.datetime.now()-start_time).total_seconds())

        except:
            self._handle_critical_exception()


    def _handle_critical_exception(self):
        '''
            try to write and close result record
        '''
        try:
            error_stack_text = traceback.format_exc()
            self._logger.critical(error_stack_text)
            error_details = DataDetailsObject()
            error_details.ErrorMessage = "Processing failed"
            error_details.Log = error_stack_text
            self._db_manager.close_result_record("Error", error_details=error_details)

        except Exception:
            logging.warning("Failed to close result record: %r", traceback.format_exc())

        raise

    def _is_workflow_step_enabled(self, step_name):
        '''
            disable certain steps for testing/debugging purposes
        '''

        # disableable steps: crm-fetch, db-fetch, db-write, crm-write
        disabled_steps = self._config["maintenance"]["disabled_workflow_steps"]
        if step_name in disabled_steps:
            self._logger.warn("Step [%s] is disabled !", step_name)
            self._logger.warn("List of disabled steps: [%s]", " ".join(disabled_steps)) 
            return False
        return True
