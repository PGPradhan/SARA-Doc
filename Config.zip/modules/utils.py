import io
import subprocess
import logging
import json
import yaml

from modules.LoggingHelper import get_logger

class DictAsMember(dict):
    def __getattr__(self, name):
        value = self[name]
        if isinstance(value, dict):
            value = DictAsMember(value)
        return value


def call_sync_external_executable(executable_name, *cmdline_args_as_list):
    logger = get_logger()
    logger.info("Run external process: %s %s", executable_name, " ".join(cmdline_args_as_list))
    completed_process_result = subprocess.run([executable_name] + list(cmdline_args_as_list))
    logger.info("External process completed, exit code=%d", completed_process_result.returncode)
    logger.info(completed_process_result.stdout)
    if completed_process_result.returncode != 0:
        logger.error(completed_process_result.stderr)
    completed_process_result.check_returncode() # raises exception if process has exit code other than 0


class JsonSerializable(object):
    def toJson(self):
        return json.dumps(self.__dict__, sort_keys=True, skipkeys=True, default=str)

    def __repr__(self):
        return self.toJson()


def load_config(yaml_config_file):
    with io.open(yaml_config_file, mode='r', encoding="utf-8") as fp:
        config = yaml.safe_load(fp)
        return DictAsMember(config)
    # do not catch any exceptions here since this is critical
