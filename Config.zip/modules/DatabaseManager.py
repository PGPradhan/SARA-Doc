import sys
import pandas as pd
import time
import sqlalchemy
from sqlalchemy.sql import table as Table, column, select, update, insert, text
import traceback
import uuid

import modules.utils as utils
from modules.LoggingHelper import get_logger

class DataDetailsObject(utils.JsonSerializable):
    '''
        Data container class holding simple values - to be serialized to JSON
    '''
    def __init__(self):
        '''dynamically add attributes/member variables to instance of this class that need to be serialized to JSON'''
        pass


class DatabaseManager():

    def __init__(self, config):
        self._config = config
        self._logger = get_logger()

        self.result_id = None
        self._db_schema = self._config.database.schema
        self._db_meta = None
        self._logger.info("DatabaseManager() initialized")
        self._init_db_engine()


    def _create_db_engine(self, mode="odbc"):
        if mode == "odbc":
            return self._create_db_engine_pyodbc()
        else:
            return self._create_db_engine_pymssql()


    def _create_db_engine_pymssql(self):
        self._logger.debug("create db engine - use pymssql")
        db_config = self._config["database"]
        if "database.windows.net" in db_config["server"]:
            db_username = "{}@{}".format(db_config["user"], db_config["server"].split('.')[0])
        else: 
            db_username = db_config["user"]

        connection_string = "mssql+pymssql://{}:{}@{}/{}".format(
            db_username,
            db_config["password"], 
            db_config["server"], 
            db_config["dbname"])
        self._logger.debug("Connectionstring: " + connection_string)
        engine = sqlalchemy.create_engine(connection_string, echo=False)
        self._logger.debug("db engine created.")
        return engine


    def _create_db_engine_pyodbc(self):
        self._logger.debug("create db engine - use pyodbc")
        db_config = self._config["database"]

        driver = db_config.get("driver", "{ODBC Driver 17 for SQL Server}")
        password = db_config["password"]
        
        connection_params = f"Driver={driver};Server=tcp:{db_config['server']},1433;Database={db_config['dbname']};Uid={db_config['user']};Pwd={password};Encrypt=yes;TrustServerCertificate=yes;Connection Timeout=30;"
        connection_string = f"mssql+pyodbc:///?odbc_connect={connection_params}"
        self._logger.debug("Connectionstring: " + connection_string.replace(password, password[0] + "***" + password[-1]))
        engine = sqlalchemy.create_engine(connection_string, echo=False)
        self._logger.debug("db engine created.")
        return engine


    def _init_db_engine(self):
        # self._logger.debug("Connectionstring: " + self._connection_string)
        self._engine = self._create_db_engine()
        self._db_meta = sqlalchemy.MetaData()
        self._db_meta.reflect(bind=self._engine)        
        self._logger.debug("Found tables: {}".format(self._db_meta.tables))
        self._logger.info(self._db_meta)
        self._logger.debug("db engine created.")


    def create_result_record(self, model_version):
        '''
            At the very begin of a processing run: 
                - Create the initial/master result record in 'Results' table.
                - retrieve and store its ID, which is required by foreign-key dependent tables (_write_db_table_XYZ)
        '''
        self._logger.info("Create/open result record, model_version=" + model_version)
        results_table = self._db_meta.tables['Results']
        with self._engine.begin() as conn:  # ContextManager handles transaction
            response = conn.execute(results_table.insert(), {'ModelVersion': model_version})
            self.result_id = response.inserted_primary_key[0] # is list

        self._logger.info("Created result record.")
        self._logger.debug("id=" + str(self.result_id))


    def quote_Nonable_for_db(self, value):
        if value is None:
            return 'Null'
        else:
            return "'{}'".format(value)


    def close_result_record(self, result_status, result_details=None, error_details=None):
        '''
            At the very end of a processing run: 
                - update master result record in 'Results' table with final outcome (=result_status) 
        ''' 
        if self.result_id is None:
            self._logger.error("Cannot close result record: ResultId is not available.")
            return 

        self._logger.info("Close result record")
        with self._engine.begin() as conn:  # begin uses ContextManager which handles transaction
            sql_query = "update [{}].[Results] set ResultStatus='{}', EndTimeUtc=GETUTCDATE(), ResultDetailsJson={}, ErrorDetailsJson={} where ResultId={}".format(self._db_schema, result_status, self.quote_Nonable_for_db(result_details), self.quote_Nonable_for_db(error_details), self.result_id)
            self._logger.info("Execute sql query: " + sql_query[0:10000] + "...")
            conn.execute(text(sql_query))
            self._logger.info("Close/update result table")


    def get_latest_model_version(self, model_version_base):
        '''
            query database for models with same date
        '''
        self._logger.info("Get previous model versions (same base model)")
        sql_query = "Select ModelVersion from [{}].[Results] where ModelVersion like '{}.%' order by ModelVersion desc".format(self._db_schema, model_version_base)
        self._logger.debug("connect")
        with self._engine.connect() as conn:  
            self._logger.debug("execute query: %s", sql_query)
            latest_model_version = conn.execute(text(sql_query)).fetchone()
            if latest_model_version is not None:
                latest_model_version = str(latest_model_version[0])
            self._logger.info("Got latest model version: ")
            self._logger.info(latest_model_version)
        return latest_model_version


    def read_db_salesorders(self):
        self._logger.info("read sales orders from database table 'CrmSalesOrders'")
        with self._engine.connect() as conn:
            sql_query = "SELECT [CustomerId], [OrderId], [OrderType], [OrderDateTime], [Amount], [CurrencyISO], [SalesOfficeId] from [{}].[CrmSalesOrders]".format(self._db_schema)
            self._logger.debug("execute query: %s", sql_query)
            df_salesorders = pd.read_sql_query(sql_query, conn) 
        self._logger.debug("Fetch complete, #salesorders: {}".format(len(df_salesorders)))
        return df_salesorders


    def _clean_candidates_db_table(self):
        return
        '''
            write/append data to table in database
        '''
        db_tablename = "[{}][SalesAlertCandidates]".format(self._db_schema)
        try:
            self._logger.info("clean db table")
            n_retained_runs = self._config.database.n_retained_runs
            sql_query = "DELETE FROM {} WHERE ResultId < {}".format(db_tablename, self.result_id - n_retained_runs)

            start_time = time.time()
            with self._engine.begin() as conn:  # begin uses ContextManager which handles transaction
                self._logger.info("Clean older runs from: " + db_tablename)
                conn.execute(sql_query)
            self._logger.info("Cleaned older runs from candidates table, duration={}s".format(time.time()-start_time))

        except:
            self._logger.error("Failed to clean database table: %s", db_tablename)
            self._logger.error(traceback.format_exc())


    def _write_db_table(self, db_tablename, dataframe, use_resultid=True, throw_ex=True):
        '''
            write/append data to table in database
        '''
        try:
            self._logger.info("write db table")
            chunksize = self._config.database.chunksize

            start_time = time.time()
            df_extended = dataframe.copy()
            if use_resultid is True:
                df_extended["ResultId"] = [self.result_id] * len(dataframe)  # add foreign-key reference

            self._logger.info("Begin transaction")
            with self._engine.begin() as conn:  # begin uses ContextManager which handles transaction
                self._logger.info("Write dataframe to db table: " + db_tablename)
                df_extended.to_sql(db_tablename, conn, schema=self._db_schema, index=False, if_exists='append', chunksize=chunksize)
            self._logger.info("Table written to database, duration={}s".format(time.time()-start_time))

        except:
            self._logger.error("Failed to write database table: %s", db_tablename)
            self._logger.error(traceback.format_exc())
            if throw_ex is True:
                raise


    def write_db_table_salesalerts(self, dataframe) :
        self._write_db_table("SalesAlertCandidates", dataframe)

    def write_db_table_crmsalesorder(self, dataframe) :  # only for dev
        self._write_db_table("CrmSalesOrders", dataframe, use_resultid=False)


if __name__ == "__main__":
    csv_file = sys.argv[1]
    # upload csv to CrmSalesOrders table
    print("Reading csv: ", csv_file)
    df = pd.read_csv(csv_file, sep=';')
    df.rename(columns={"SalesOffice": "SalesOfficeId"}, inplace=True)
    df["Amount"] = df.Amount.astype(str).apply(lambda x: x.replace(',', '.')).astype(float)
    df["SalesOfficeId"] = [uuid.uuid4() for i in range(len(df))]
    df["OrderDateTime"] = pd.to_datetime(df.OrderDateTime, errors='coerce')
    df = df[["CustomerId", "OrderId", "OrderDateTime", "OrderType", "Amount", "CurrencyISO", "SalesOfficeId"]]
    print(df.info())
    dbm = DatabaseManager(utils.load_config('..\\Config\\salesalerts.yaml'))
    dbm.write_db_table_crmsalesorder(df)
