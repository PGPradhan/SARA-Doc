import pandas as pd
import numpy as np
import logging
import datetime

from modules.LoggingHelper import get_logger

class SalesAlerts():
    """ 
        t.b.d.  class code
    """

    '''
    Calculation of the individual limit on days on which an alarm is generated
    for the respective customer if that limit is exceeded
    '''

    def __init__(self, config_dictionary):
        self.config = config_dictionary
        self.quantile = self.config.SalesAlert.paramaters.quantile
        self.std_span = self.config.SalesAlert.paramaters.standard_deviation_span
        self.std_span_offset = self.config.SalesAlert.paramaters.standard_deviation_span_offest
        self.offset = self.config.SalesAlert.paramaters.offset
        self.ewm_span = self.config.SalesAlert.paramaters.ewm_span
        self.ewm_orders = self.config.SalesAlert.paramaters.ewm_orders
        self.std_orders = self.config.SalesAlert.paramaters.std_orders
        self.std_factor = self.config.SalesAlert.paramaters.std_factor
        self.AIRuleId = self.config.SalesAlert.AI_RuleId
        self.df_threshold_days = None
        self._logger = get_logger()
        self.df_salesalerts = None
        self.df_passed_days_orders = None
        
        self.nof_salesalerts = None
        self.IsDisabledTimeFrame = None

    def calc_passed_days(self, df_salesorders, customers):
        '''
        Calculate days passed between each order for each customer within time window.
        And days between reference day and last order.
        '''
        self._logger.debug("Initialization of calculation of past days")

        lst_cust_passed_days = []
        
        self.df_passed_days_orders = pd.DataFrame()
        ref_date = datetime.date.today()
        #ref_date = datetime.date(2019,12,15)

        for cust in customers:
            # get list of all Orders of each customer
            calc_diff = sorted(df_salesorders["OrderDate"][df_salesorders["CustomerId"] == cust].values)
            # append reference date to list
            calc_diff.append(ref_date)
            # calc difference between dates
            calc_diff = pd.DataFrame(data=calc_diff)
            calc_diff.drop_duplicates(keep="first", inplace=True)
            cust_passed_days = calc_diff.diff().dropna()
            cust_passed_days = cust_passed_days[0].apply(lambda x: x.days)
            lst_cust_passed_days.append(pd.DataFrame({cust: cust_passed_days}))
            
        self.df_passed_days_orders = pd.concat(lst_cust_passed_days, axis=1)
        
        # Since the number of days between two orders is of interest, 
        # 1 is subtracted everywhere. If an order is received for the same day as the evaluation takes place, 
        # the value 0 has the exception that 1 is not subtracted.
        self.df_passed_days_orders = self.df_passed_days_orders.where(self.df_passed_days_orders == 0, other = self.df_passed_days_orders.sub(1))

        self._logger.debug("Completion of calculation of past days")

        return self.df_passed_days_orders


    def calc_quantile_limit(self, df_passed_days_orders):
        '''
        Calculate the number of days after which an alert will be generated,
        based on a specified quantile
        '''
        self._logger.debug("Initialization of calculation of threshold limit using quantile")

        self.df_threshold_days = df_passed_days_orders.quantile(self.quantile)
        self.df_threshold_days.name = "Last Order Date"
        self._logger.info("Limit Days were calculated based on Quantile: " + str(self.quantile))

        self._logger.debug("Completion of calculation of threshold limit using quantile")

    def calc_idl_value_2(self, customers, df_passed_days_orders):

        self._logger.debug("Initialization of calculation of threshold limit using EWM_2.0")

        lst_current_idl_value = []
        for cust in customers:
            df_idl = pd.DataFrame()
            ewm_span_var = round(len(df_passed_days_orders[cust].dropna()) * (self.ewm_orders / 100))

            if ewm_span_var == 0:
                ewm_span_var = 1
            # Calculation of an exponentially weighted function based on a percentage of previous orders
            df_idl["IDL"] = df_passed_days_orders[cust].dropna().iloc[:-1].sort_index(ascending=True).ewm(span=ewm_span_var, adjust=False).mean().sort_index(ascending=True)
            
            std_span_var = round(len(df_passed_days_orders[cust].dropna()) * (self.std_orders)/100)

            if std_span_var <= 1:
                std_span_var = 2

            df_idl["STD"] = df_idl["IDL"].add(df_passed_days_orders[cust].dropna().rolling(std_span_var).std().round())
            df_idl["IDL"] = df_idl["IDL"].add(df_idl["STD"].multiply(self.std_factor))
            df_idl = df_idl.drop(["STD"], axis=1)

           # Adding an offset of days to the calculated limit value of the last value
            df_idl["IDL"] = df_idl["IDL"].where(df_idl["IDL"] >= self.offset, other=self.offset)

            lst_current_idl_value.append(df_idl["IDL"].iloc[-1])
         
        self.df_threshold_days = pd.DataFrame(data=lst_current_idl_value, index=customers, columns=["Individual Dynamic Limit"])

        self._logger.debug("Completion of calculation of threshold limit using EWM_2.0")



    def calc_idl_value(self, customers, df_passed_days_orders):
        '''
        Calculate the Individual Dynamic Limit:
        1.  Calculate an exponentially weighted average of the number of days
            between two orders for each customer over the last 365 days,
            so that the closer order pattern has a greater impact on the
            average.

        2.  Adding the standard deviation of the average days between two
            orders of the maximum last x orders (std_span). This standard
            deviation is then multiplied by a factor (std_factor).

        3.  Adding a fixed offset of days (offset).

        The result is a number of days for each customer, 
        representing the days between the last order and the next expected order 
        '''
        self._logger.debug("Initialization of calculation of threshold limit using EWM")
        
        lst_current_idl_value = []
        df_idl = pd.DataFrame()
        for cust in customers:
            df_idl = pd.DataFrame()
            # Calculation of an exponentially weighted function based on a span of 365 days 
            df_idl["IDL"] = df_passed_days_orders[cust].dropna().iloc[:-1].ewm(span=self.ewm_span).mean()
            # Adding the standard deviation for a certain time period ("std_span") and multiplying a factor to the std

            '''
            the calculation of a rolling standard deviation produces NaNs for the first x-values, 
            so this method is only used if the number of orders in the considered period is greater 
            than x + offset. Otherwise, the standard deviation of the considered period is used
            '''

            if len(df_idl) > self.std_span + self.std_span_offset:
                df_idl["STD"] = df_idl["IDL"].add(df_passed_days_orders[cust].dropna().iloc[:-1].rolling(self.std_span).std().round())
            else:
                df_idl["STD"] = df_idl["IDL"].add(df_passed_days_orders[cust].dropna().iloc[:-1].std())

            df_idl["IDL"] = df_idl["IDL"].add(df_idl["STD"].multiply(self.std_factor))
            df_idl = df_idl.drop(["STD"], axis=1)
            
            # Adding an offset of days to the calculated limit value of the last value
            df_idl["IDL"] = df_idl["IDL"].where(df_idl["IDL"] >= self.offset, other=self.offset)
    
            lst_current_idl_value.append(df_idl["IDL"].iloc[-1])
         
        self.df_threshold_days = pd.DataFrame(data=lst_current_idl_value, index=customers, columns=["Individual Dynamic Limit"])

        self._logger.debug("Completion of calculation of threshold limit using EWM")
 
    def test_for_SalesAlert_pause_Date(self, config):
        try:
            logger = get_logger()
            logger.debug("test whether current date is within pause window")

            # convert window (strings) to time
            pause_time_window_start = datetime.datetime.strptime(str(datetime.datetime.today().year) + ', ' + config.SalesAlert.Pause.pause_window_start, '%Y, %m, %d').date()
            pause_time_window_end = datetime.datetime.strptime(str(datetime.datetime.today().year +1) + ', ' + config.SalesAlert.Pause.pause_window_end, '%Y, %m, %d').date()
            logger.debug("Pause window start: {},  type: {}".format(pause_time_window_start, type(pause_time_window_start)))
            logger.debug("Pause window end: {},  type: {}".format(pause_time_window_end, type(pause_time_window_end)))

            now = datetime.date.today()
            logger.debug("current time: {}".format(now))
            if now >= pause_time_window_start and now <= pause_time_window_end:
                return True

            return False
        except:
            return False     

    def check_exceedance(self, df_salesorders, df_passed_days_orders, customers):
        '''
        Check whether the respective customer has exceeded his previously
        calculated limit days
        '''

           
        
        lst_customer = []
        lst_exceedance_check = []
        lst_last_order_date = []
        lst_expected_order_date = []
        lst_AverageOrderIntervalDays = []

        self._logger.debug("Initialization of the check whether the calculated threshold value is exceeded")


        for cust in customers:

            lst_customer.append(cust)
            # Check whether the days between the reference day and the last order exceed the threshold days
            lst_exceedance_check.append(df_passed_days_orders[cust].dropna().iloc[-1] > int(self.df_threshold_days.loc[cust]))
            # Get date of last order 
            lst_last_order_date.append(df_salesorders["OrderDate"][df_salesorders["CustomerId"] == cust].max())
            # Calculate median of days between orders
            lst_AverageOrderIntervalDays.append(int(df_passed_days_orders[cust].dropna().median()))
            # Calculate expected order date, by adding thershold days to last order
            lst_expected_order_date.append(df_salesorders["OrderDate"][df_salesorders["CustomerId"] == cust].sort_values().iloc[-2] + datetime.timedelta(days=int(self.df_threshold_days.loc[cust])))

        # List of apllied AI
        lst_AIRuleId = [self.AIRuleId] * len(lst_exceedance_check)
        self.df_salesalerts = pd.DataFrame([lst_exceedance_check, lst_last_order_date, lst_expected_order_date, lst_AIRuleId, lst_AverageOrderIntervalDays],
        columns=lst_customer, index=["Exceedance Check", "LastOrderDate", "ExpectedOrderDate", "AIRuleId", "AverageOrderIntervalDays "]).T

        # Removal of the data which do not exceed the threshold value days
        self.df_salesalerts = self.df_salesalerts[self.df_salesalerts["Exceedance Check"]].drop("Exceedance Check", axis=1)
        self.df_salesalerts["CustomerId"] = self.df_salesalerts.index.values
        self.nof_salesalerts = len(self.df_salesalerts)

        if self.test_for_SalesAlert_pause_Date(self.config):
            self.IsDisabledTimeFrame = True
            self._logger.info("SalesAlert paused - CopyToCrm set to 0.")
            self.df_salesalerts['CopyToCrm'] = 0 * len(self.df_salesalerts)

        else: self.IsDisabledTimeFrame = False
        self._logger.info(str(self.nof_salesalerts) + " SalesALerts are created for " + str(len(lst_customer)) + " relevant Customers")
        self._logger.debug("Completion of the check whether the calculated threshold value is exceeded")




    def init_AIRule(self, customers, df_passed_days_orders):

        if self.AIRuleId == 1:
            self.calc_idl_value(customers, df_passed_days_orders)

        elif self.AIRuleId == 2:
            self.calc_idl_value_2(customers, df_passed_days_orders)

        elif self.AIRuleId == 3:
            self.calc_quantile_limit(df_passed_days_orders)



