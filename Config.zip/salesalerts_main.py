
import argparse
import logging
import time
import datetime
import subprocess
import traceback
from modules.LoggingHelper import init_logging, get_logger
from modules.utils import load_config
from modules.MainProcessingControl import MainProcessingControl
from modules.CrmManager import CrmManager


APPLICATION_NAME = "SALESALERTS"
FALLBACK_LOG = './fatal.log'

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('config', help='filename including path to yaml configuration file', nargs='?', default='./Config/salesalerts.yaml')
    parser.add_argument('--update', action='store_true', help='update statically computed data, e.g. sara PG mapping')
    parser.add_argument('--shutdown', action='store_true', help='run Powershell script after workflow execution to shutdown/deallocate Azure Virtual Machine')
    parser.add_argument('--autostart', action='store_true', help='the script is auto-started by task scheduler - take maintenance windows in account')

    args = parser.parse_args()
    return args



def test_for_maintenance_window(config):
    try:
        logger = get_logger()
        logger.debug("test whether current time is within maintenance window")

        # convert window (strings) to time
        maintenance_time_window_start, maintenance_time_window_end = [datetime.datetime.strptime(dt,"%H:%M:%S").time() for dt in config["maintenance"]["time_window"]] # [ start, end ]
        logger.debug("Maintenance window start: {},  type: {}".format(maintenance_time_window_start, type(maintenance_time_window_start)))
        logger.debug("Maintenance window end: {},  type: {}".format(maintenance_time_window_end, type(maintenance_time_window_end)))

        now = datetime.datetime.now().time()
        logger.debug("current time: {}".format(now))
        if now >= maintenance_time_window_start and now < maintenance_time_window_end:
            return True

        return False
    except:
        return False




def shutdown_virtual_machine(config):
    logger = get_logger()
    logger.info("Shutdown/Deallocate Virtual Machine")
    logger.debug("Delay execution of shutdown for 10 minutes")
    time.sleep(600)  # safe-guard: prevent immediate VM shutdown after VM start with a SARA error 

    logging.info("Run shutdown powershell script")
    p = subprocess.Popen(["powershell", "-File", "vm_shutdown.ps1"])
    logging.info("External process started...")
    (output, err) = p.communicate()  
    p_status = p.wait()
    logging.info("External process completed, output=%s, error=%s", output, err)


def get_run_id() -> str:
    ''' 
        Create a unique identifier for this run
        Allows to distinguish runs in Azure Monitoring
    '''
    startTime = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    return f"{APPLICATION_NAME}-{startTime}"


def main(args):

    # set a unique identifier for this run
    run_id = get_run_id()

    init_logging(args.config, application=APPLICATION_NAME, run_id=run_id)
    logger = get_logger()

    try:
        logger.info("SALESALERTS started, run_id=%r", run_id)
        config = load_config(args.config)
        CrmManager.yaml_config_file = args.config

        # In production this main script is started by a Scheduled Task after the startup of the hosting virtual machine.
        # The Scheduled Task action needs to be started with a delay (~10-15 minutes) in order to give time to maintenance user to create a marker file
        if args.autostart is True and test_for_maintenance_window(config):
            logger.info("Autostart within maintenance window detected - run aborted.")
            return

        logger.info("Initialize main processing workflow")
        mainProcessingControl = MainProcessingControl(config)
        logger.info("Start main processing workflow")
        if args.update is True:
            mainProcessingControl.update_auxiliary_tables()
        else:
            mainProcessingControl.run_workflow()

        logger.info("SALESALERTS, final result [OK], run_id=%r", run_id)
    except Exception:
        traceback.print_exc() # also to stdout
        logger.exception("CRITICAL error occurred")
        logger.critical("SALESALERTS, final result [ERROR], run_id=%r", run_id)

    # shutdown VM. 
    #   A *TEMPORARY* marker file can be created to prevent the script based shutdown - this has to be removed manually afterwards !
    if args.shutdown is True:
        shutdown_virtual_machine(config)

    



if __name__ == "__main__":
    args = get_args()
    vars(args)
    main(args)
    print ("done.\n")


        