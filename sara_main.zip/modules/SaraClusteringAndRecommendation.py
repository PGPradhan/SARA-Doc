import pandas as pd
import numpy as np
import logging
from sklearn import cluster
from sklearn.neighbors import KNeighborsClassifier
from sklearn import metrics

from modules.LoggingHelper import get_logger


class SaraClustering():
    """ Calculation of customer segments / peer groups on Sara data. This includes normalization, data preparation, the clustering itself and a postprocessing step.
    Further explanations:
    To calculate meaningfull clusters, the first step is to normalize the data. First the groups are normalized over all customers. This is necessary to weight
    the different groups equaly. Otherwise groups with high revenue would be treated with an higher priority. That case could be considered for a recommendation
    engine to increase revenue, but not for a cross-selling solution. In the second normalization step, the data is normalized over all product groups within one
    customer. This steps provides a normalized customer profile, with the value 1 being the most important product group for the customer. Every other value is
    between 0 and 1 with 0 being totaly unimportant/no sales. The second normalization is important to weight the needs of customers equally. During the
    normalization customers with no sales an product groups without revenue are excluded, as the don't provide any information.
    After the normalization the data gets prepared for clustering. First the data gets split into two sets. One set includes all customers with revenue in at
    least two product groups. This set will be used for clustering. The data for the remaining data is stored seperated. This data is not meaningfull for
    clustering as a customer needs revenue in at least two product groups. One for assignment to a cluster and one for recommendation. The second set will be used
    to be assigned to a peergroup after clustering.
    Later the actual clustering will be performed. Therefore kmeans is used.
    To assigne peergroups to the customers with sales in only one product group a knn-classifier will be used.

    Args:
        dataframe (pandas.DataFrame): Data frame with one row per customer and one column per product group with the row index being the customer number.
        config_dictionary (dict): The Sara configuration dictionary.
    """

    def __init__(self,dataframe,config_dictionary):
        config = config_dictionary
        self.data= dataframe
        self.n_clusters = config["nof_cluster"] # Number of clusters to calculate.
        self.number_nearest_neighbors = config["number_nearest_neighbors"] # Number of nearest neighbors in AssignClusterToUnclusteredCustomers.
        self.data_scaled = None # Data after normalizing.
        self.customers = dataframe.index # Customer number.
        self.customers_clustering = None # Custumer numbers used for clustering.
        self.columnnames = None # Names of product groups used for clustering.
        self.matrix_clustering = None # Data for clustering.
        self.customers_knn = None # Customer number not used for clustering.
        self.matrix_knn = None # Data for knn.
        self.cluster_labels = None # Peer group numbers
        self._logger = get_logger()
        

    def NormalizeGroupsMean(self):
        """ Normalize the data along one product group over all customers by dividing by the group average.
        """
        self._logger.info('Start normalize groups ...')
        self.data = self.data.loc[(self.data.sum(axis=1) > 0), (self.data.sum(axis=0) > 0)] # Remove groups and customers without any revenue.
        self.data_scaled = self.data.apply(lambda row: row/row[row>0].mean(),axis=0).copy() # Divide by average over all positive values in each group. 
        #Ignore customers without revenue in the product group. Otherwise groups with only few involved customers would be weighted higher.


    def NormalizeCustomersMax(self):
        """ Normalize the data along one customer over all product groups by dividing by the customers maximum value.
        """
        self._logger.info('Start normalize customers ...')
        self.data_scaled = self.data_scaled.apply(lambda row: row/row.max(),axis=1).copy()

    def PrepareDataForClustering(self):
        """ Prepare data for clustering. The pandas data frame is transformed to a numpy array with two dimensions.
        """
        self._logger.info('Start perpare data for clustering ...')
        self._logger.debug('Data rows (customer):'+str(self.data.shape[0]))
        self._logger.debug('Data columns (product groups):'+str(self.data.shape[1]-1))

        # Split data into two sets. One with customer data suitable for clustering and one with all the rest.
        data_for_clustering = self.data_scaled[self.data_scaled.sum(axis=1)>1] # Removing customers with revenue in less then two product groups.
        data_for_knn = self.data_scaled[self.data_scaled.sum(axis=1)==1] # Storing data for customers with revenue in only one product group.
        # This data frame will be used to assign clusters to those customers in the post processing step.
        self._logger.debug('Data has been reduced')

        # Shaping data for clustering.
        self.customers_clustering = data_for_clustering.index
        self.columnnames = data_for_clustering.columns
        self.matrix_clustering =  np.array(data_for_clustering[self.columnnames])
        
        # Shaping data for cluster assignement.
        self.customers_knn = data_for_knn.index
        self.matrix_knn = np.array(data_for_knn[self.columnnames])

    def ClusterData(self):
        """ Clustering data using kmeans.
        """
        self._logger.info('Start clustering kmeans ...')
        kmeans = cluster.KMeans(self.n_clusters,n_init=200,max_iter=500)#.fit(X)
        self.cluster_labels = kmeans.fit_predict(self.matrix_clustering)
        self._logger.debug('Clustering finished with '+ str(len(self.cluster_labels))+' customers')
        self._logger.info("Found %d cluster", kmeans.n_clusters)

    def AssignClusterToUnclusteredCustomers(self):
        """ Assign clusters to customers not used for clustering.
        """
        self._logger.info('Start assign customers to clusters ...')
        knn = KNeighborsClassifier(n_neighbors=self.number_nearest_neighbors)
        knn.fit(self.matrix_clustering, self.cluster_labels)
        self._logger.debug('knn has been fitted')
        predicted_cluster_labels = knn.predict(self.matrix_knn)
        self._logger.debug(str(len(predicted_cluster_labels))+' customers were assigned to clusters by knn')

        cluster_data = pd.DataFrame(data=self.matrix_clustering,columns=self.columnnames, index=self.customers_clustering)
        knn_data = pd.DataFrame(data=self.matrix_knn,columns=self.columnnames, index=self.customers_knn)

        cluster_data["PeerGroupId"]=self.cluster_labels
        knn_data["PeerGroupId"]=predicted_cluster_labels

        self.data = pd.concat([cluster_data,knn_data])
        self.data["PeerGroupId"] = self.data["PeerGroupId"].astype(int).astype(str)
        self._logger.debug('After the clustering the number of customers in clusters is:'+ str(len(self.data)))




class SaraRecommendations():
    """ Calculate Sara Recommendations. 
    First the peer groups are calculated using SaraClustering.
    In a second step the peer groups are used to calculate the top groups for each peer group. Based on these top groups and eachs customer's profile recommendations can be calculated and written into a data frame.
    """

    def __init__(self,config_dictionary):
        self.config = config_dictionary["clustering"]
        self.exclude_unstable_clusters = self.config["exclude_unstable_clusters"] # Boolean. If true, peer groups with low silhouette score are excluded from recommendation system.
        self.exclude_uncertain_customers = self.config["exclude_uncertain_customers"] # Boolean. If true, customers with low silhouette score are excluded from recommendation system.
        self.rules = self.config["rules"]
        self.minimum_recommendation_ranking_value = self.config["minimum_recommendation_ranking_value"] # Float. Minimum profile value for product groups to qualify for recommendation.
        self.maximum_recommendation_order_depth = self.config["maximum_recommendation_order_depth"] # Integer. Maximum recommendations allowed per customer and recommendation rule.
        self.maximum_unsold_n = self.config["maximum_unsold_n"] # Parameter for unsold n.
        self.data = None 
        self.all_customers = None
        self.columnnames = None
        self.full_data = None
        self.nof_peergroups = None
        self.sales_data = None
        self.top_groups = None
        self.top_groups_values = None
        self.top_groups_with_values = None
        self.top_groups_recommend = None
        self.recommendation_data = None
        self.customer_cluster_mapping = None
        self.no_recomendation = "no recommendation"
        self.recommendation_not_valid= "recommendation not valid"
        self.clustering = None
        self._logger = get_logger()


    def __cluster_data(self):
        """ Calculate Peergroups as discribed in SaraClustering.
        """
        self._logger.info('Start peergroup clustering ...')
        clustering = SaraClustering(self.data,self.config)
        clustering.NormalizeGroupsMean()
        clustering.NormalizeCustomersMax()
        clustering.PrepareDataForClustering()
        clustering.ClusterData()
        clustering.AssignClusterToUnclusteredCustomers()
        self.data = clustering.data
        self.all_customers = clustering.customers
        self.columnnames = clustering.columnnames
        self.full_data = self.data.copy()
        self.clustering = clustering


    
    def __select_customers(self):
        """
        """
        self._logger.info('Start select customers ...')
        columnnames = self.data.drop("PeerGroupId",axis=1).columns
        X = np.array(self.data[columnnames])

        self._logger.debug('Calculating Silhouette Score')
        self.data["CustomerScore"] = metrics.silhouette_samples(X,self.data["PeerGroupId"]) # Calculate Silhouette Score for every customer.
        clusters_with_scores= self.data.groupby(['PeerGroupId'], as_index=False).mean()[["PeerGroupId","CustomerScore"]] # Calculate average Silhouette Score for every peer group.
        clusters_to_use = clusters_with_scores[clusters_with_scores["CustomerScore"]>0.1]["PeerGroupId"] # Find homogeneous cluster with Silhouette Score larger than 0.1.

        # Exclude heterogenous cluster if selected in config dict.
        if self.exclude_unstable_clusters==True:
            self._logger.info('Exclude heterogen clusters ...')
            n_before = len(self.data)
            self.data = self.data[self.data["PeerGroupId"].isin(clusters_to_use)]
            n_after = len(self.data)
            n_delta = n_before - n_after
            self._logger.debug(str(n_delta) +' customers from unstable clusters were excluded.')

        # Exclude customers with non-positive Silhouette Scores. These customers are near the perimiter of a cluster.
        if self.exclude_uncertain_customers==True:
            self._logger.info('Exclude unstable assigned customers ...')
            n_before = len(self.data)
            self.data = self.data[self.data["CustomerScore"]>0]
            n_after = len(self.data)
            n_delta = n_before - n_after
            self._logger.debug(str(n_delta) +' customers with low silhouette scores were excluded.')
        
        self.data = self.data.drop(["CustomerScore"],axis=1)
        self.data_after_clustering = self.data.copy()
        self.nof_peergroups = len(self.data["PeerGroupId"].unique())

    def __calculate_top_groups(self):
        """ Create three data frames describing the top groups for each cluster:

        self.top_groups (pandas.DataFrame): Data frame with sorted product group names per peer group with peer group ids as index:
                    1       2       3       4       ...
                0   "h1"    "x2"    "v3"    "z4"    ...
                1   "ap5"   "hx6"   "id7"   "oj5"   ...
                ... ...     ...     ...     ...     ...

        self.top_groups_values (pandas.DataFrame): Data frame with average values for sorted product groups per peer group with peer group ids as index:
                    1       2       3       4       ...
                0   0.91    0.42    0.12    0.07    ...
                1   0.87   0.76     0.32    0.09    ...
                ... ...     ...     ...     ...     ...

        self.top_groups_with_values (pandas.DataFrame): Data frame combining the information of self.top_groups_values and self.top_groups with one row per
                peer group and product group:
                    "PeerGroupId"   "RankingPosition"   "SaraProductGroup"      "RankingValue"
                0   0               1                   "h1"                    0.91
                1   0               2                   "x2"                    0.42
                ... ...             ...                 ...                     ...
                168 1               1                   "ap5"                   0.87
                ... ...             ...                 ...                     ...
        """
        self._logger.info('Start calculate top groups per cluster ...')
        test_data = self.data.groupby(['PeerGroupId']).mean() # Create data frame with product group averages for every peer group.
        top_group_list = []
        top_group_val_list = []
        # Sort product groups for every cluster.
        # Result are two lists of lists.
        # top_group_list: List with product group names for every peer group. E.g. [["h1", "x2", "z3", ....
        # top_group_list_val: List with product group values for every peer group. E.g. [["0.9", "0.5", "0.2", ....
        for cluster in test_data.index:
            single_group = [x for _,x in sorted(zip(test_data.loc[cluster,],self.columnnames),reverse=True)] 
            single_group_val = sorted(test_data.loc[cluster,],reverse=True)
            top_group_list.append(single_group)
            top_group_val_list.append(single_group_val)
        self._logger.debug('Finished calculating the top groups as lists')

        column_names = [str(x) for x in list(range(test_data.shape[1]))]
        self._logger.debug('convert top groups to pandas dataframe')
        self.top_groups = pd.DataFrame(data=top_group_list,columns=column_names,index=test_data.index)
        self.top_groups_values = pd.DataFrame(data=top_group_val_list,columns=column_names,index=test_data.index)
        self._logger.debug('rename top groups dataframes')
        top_groups = self.top_groups
        top_groups["PeerGroupId"] = top_groups.index
        top_groups_values = self.top_groups_values
        top_groups_values["PeerGroupId"] = top_groups_values.index
        self._logger.debug('melt top groups dataframes')
        tgl = pd.melt(top_groups, id_vars="PeerGroupId",var_name="RankingPosition",value_name="Group")
        tgvl = pd.melt(top_groups_values, id_vars="PeerGroupId",var_name="RankingPosition",value_name="Group")
        self._logger.debug('create top_groups_with_values')
        self.top_groups_with_values = pd.merge(tgl,tgvl,how="outer",on=["PeerGroupId","RankingPosition"]).rename(index=str,columns={"Group_x":"SaraProductGroup","Group_y":"RankingValue"})
        self.top_groups_with_values["RankingPosition"] = pd.to_numeric(self.top_groups_with_values["RankingPosition"])+1



    def __recommendy_x(self,row,x,y):
        """ Generalized recommendation rule of "5-1". We call this kind of rules “y-x” where y indicates the number of
        top groups in a cluster we are looking at and x is the number of groups of these y groups the customer has not
        bought in. For example, the rule “5-1” only recommends product groups to customer with sales in 4 of these 5
        top product groups. These kind of rules have two huge disadvantages. They only make a recommendation to a few
        customer who meet the conditions of sales in the top product groups and they only provide a recommendation once per customer.

        Args:
            row (pandas.Series): Row of self.data including the columns "PeerGroupId", "CustomerId" and all product groups.
            x (int): Number of product groups without sales in top y product groups.
            y (int): Number of top product groups to take in account.

        Returns:
            pandas.DataFrame with one row and four columns (SaraProductGroup, CustomerId, RecommendationRule and RecommendationOrder. For this
                rule only recommendations with RecommendationOrder 1 are take into account.
        """
        cluster_num = row["PeerGroupId"]
        CustomerId = row["CustomerId"]
        cluster_top5 = self.top_groups.loc[cluster_num,:].values.flatten() # Get sorted product group names for the selected peer group.
        cust_normmax_top5 = row[list(cluster_top5)] # Get customers profile sorted by the peer groups sorted product groups.
        no_groups = y-sum((cust_normmax_top5==0).values[:y]) # Number of top y product groups with sales.
        if no_groups == (y-x):
            candidates =  self.top_groups_recommend.loc[cluster_num,:].values.flatten()[(cust_normmax_top5==0).values] # Get top product groups with no sales by customer.
            recommendation = candidates[0]
            recommendation_df = pd.DataFrame({"SaraProductGroup": recommendation, "CustomerId": CustomerId, "RecommendationRule": str(y)+"_minus_" +str(x), "RecommendationOrder":  1}, index=[0])
        else:
            recommendation_df = pd.DataFrame({"SaraProductGroup": self.no_recomendation, "CustomerId": CustomerId, "RecommendationRule": str(y)+"_minus_" +str(x), "RecommendationOrder":  1}, index=[0])
        return(recommendation_df)

    def __recommend_n_best_unsold(self,row,n):
        """ With this rule the recommendation is always the best rated group which has no sales by the customer. With this rule every
        customer can get a recommendation as long as he has not bought products out of every available group within the top 5.

        Args:
            row (pandas.Series): Row of self.data including the columns "PeerGroupId", "CustomerId" and all product groups.
            n (int): Minimum number of top product groups with sales for the customer within the top 5 product groups.

        Returns:
            pandas.DataFrame with one or more rows and four columns (SaraProductGroup, CustomerId, RecommendationRule and RecommendationOrder.
        """
        cluster_num = row["PeerGroupId"]
        CustomerId = row["CustomerId"]
        top_groups = self.top_groups.drop(columns=["PeerGroupId"])
        #self.top_groups.to_csv("./output/top_groups.csv")
        #cluster_top5 = top_groups.loc[cluster_num,]
        #cluster_top5.to_csv('./output/cluster_top5.csv')
        cluster_top5 = top_groups.loc[cluster_num,].values.flatten() # Get sorted product group names for the selected peer group.
        #pd.Series(cluster_top5).to_csv('./output/srs_cluster_top5.csv')
        #self._logger.debug("cluster_top5: %r", list(cluster_top5))

        cust_normmax_top5 = row[list(cluster_top5)] # Get customers profile sorted by the peer groups sorted product groups.
        #self._logger.debug("cluster_top5: %r  %r", type(cust_normmax_top5), cust_normmax_top5)
        no_groups = 5-sum((cust_normmax_top5==0).values[:5]) # Number of top 5 product groups with sales.
        if no_groups >= n:
            candidates = self.top_groups_recommend.loc[cluster_num,]
            #candidates.to_csv(f'./output/candidates_{n}.csv')
            candidates = self.top_groups_recommend.loc[cluster_num,].values.flatten()[(cust_normmax_top5==0).values]
            
            recommendation = candidates[:self.maximum_recommendation_order_depth]
            recommendation_df = pd.DataFrame({"SaraProductGroup": recommendation, "CustomerId": CustomerId, "RecommendationRule": "best_unsold_min_"+str(n), "RecommendationOrder": range(1,self.maximum_recommendation_order_depth+1)})
            #recommendation_df.to_csv(f'./output/recommendation_{n}.csv')
        else:
            recommendation_df = pd.DataFrame({"SaraProductGroup": self.no_recomendation, "CustomerId": CustomerId, "RecommendationRule": "best_unsold_min_"+str(n), "RecommendationOrder":  range(1,self.maximum_recommendation_order_depth+1)})
        return(recommendation_df)

    def __highest_potential(self,row):
        """  This recommendation rule recommends the product group that is expected to increase the sales volume the most.
        This recommendation would be made regardless if the customer already bought in this group or not. 

        WARNING: This rule has not been evaluated yet!

        Args:
            row (pandas.Series): Row of self.data including the columns "PeerGroupId", "CustomerId" and all product groups.

        Returns:
            pandas.DataFrame with one or more rows and four columns (SaraProductGroup, CustomerId, RecommendationRule and RecommendationOrder).
        """
        cluster_num = row["PeerGroupId"]
        customerid = row["CustomerId"]
        cluster_top5 = self.top_groups.loc[self.top_groups["PeerGroupId"]==cluster_num,].drop(["PeerGroupId"],axis=1).values.flatten() # Get sorted product group names for the selected peer group.
        customer_sorted = row[cluster_top5].values # The customers profile sorted by the clusters ranking.
        cluster_profile = self.top_groups_values.loc[cluster_num,].drop(["PeerGroupId"]).values # Cluster profile with same sorting as customer_sorted.
        customer_profile = cluster_profile-customer_sorted # Difference between customer and cluster profile.
        cluster_top5[customer_profile<=self.minimum_recommendation_ranking_value] = self.recommendation_not_valid # Delete recommendations with a low ranking value.
        customer_top5 = cluster_top5[np.argsort(-customer_profile)]
        candidates = customer_top5
        recommendation = candidates[:self.maximum_recommendation_order_depth] # Truncate to selected order depth.
        recommendation_df = pd.DataFrame({"SaraProductGroup": recommendation, "CustomerId": customerid, "RecommendationRule": "highest_potential", "RecommendationOrder": range(1,self.maximum_recommendation_order_depth+1)})
        return(recommendation_df)



    def __count_sales_per_cluster(self):
        """ Function to create two pandas data frames.

        self.sales_per_cluster_and_group: 
            One row per peer group and product group showing the number of custumers with sales.
                    "PeerGroupId"   "SaraProductGroup"  "number_of_sales_in_group"
                0   0               "h1"                342
                1   0               "x1"                21
                ... ...             ...                 ...

        self.customers_per_cluster: Frequency table of customers in peer groups.
                "PeerGroupId"   "number_of_customers"
            0   0               2341
            1   1               765
        """
        self._logger.info('Count sales per cluster ...')
        data_count_sales = self.data
        cluster = data_count_sales["PeerGroupId"]
        data_count_sales = data_count_sales.drop("PeerGroupId",axis=1)
        data_count_sales[data_count_sales>0] = 1
        data_count_sales["PeerGroupId"] = cluster
        self._logger.debug('calculate sales per cluster')
        sales_per_cluster_and_group = data_count_sales.groupby(["PeerGroupId"], as_index=False).sum()
        self.sales_per_cluster_and_group = pd.melt(sales_per_cluster_and_group,id_vars="PeerGroupId",var_name = "SaraProductGroup",value_name="number_of_sales_in_group")
        self._logger.debug('calculate clustersize')
        customers_per_cluster = data_count_sales.groupby(["PeerGroupId"], as_index=False).count().iloc[:,:2]
        self.customers_per_cluster = customers_per_cluster.rename(index=str, columns={customers_per_cluster.columns[1]: "number_of_customers"})

    def __calculate_recommendation_details(self):
        """ Add the column "RecommendationDetails" to self.recommendation_data.

        The column looks like this: "{ "NumberOfBuyersInPeerGroup": "123", "SizePeerGroup": "1234"}"
        """
        self.__count_sales_per_cluster()
        self.collect_customer_cluster_mapping()
        self._logger.info('Start calculate recommendation details ...')
        recommendation_details_data = self.recommendation_data[["CustomerId","SaraProductGroup"]]
        self._logger.debug('add PeerGroupID')
        recommendation_details_data = pd.merge(recommendation_details_data,self.customer_cluster_mapping,on="CustomerId",how="left").drop("CustomerId",axis=1)
        self._logger.debug('add PeerGroup size')
        recommendation_details_data = pd.merge(recommendation_details_data,self.customers_per_cluster,on="PeerGroupId",how="left")
        self._logger.debug('add sales per cluster and recommendation')
        
        recommendation_details_data = pd.merge(recommendation_details_data,self.sales_per_cluster_and_group,on=["PeerGroupId","SaraProductGroup"],how="left").drop(["SaraProductGroup","PeerGroupId"],axis=1)
        self._logger.debug(recommendation_details_data.head(10))
        self._logger.debug('create Json String')
        self.recommendation_data["RecommendationDetails"]= '{ "NumberOfBuyersInPeerGroup":"'+ recommendation_details_data["number_of_sales_in_group"].astype(int).astype(str)+'", "SizePeerGroup":"'+recommendation_details_data["number_of_customers"].astype(int).astype(str)+'" }'

    

    def __recommend_groups(self):
        """ Get recommendations based on peer group clustering and rules.
        """
        self._logger.info('Start calculate recommendations ...')
        data = self.data
        data["CustomerId"] = data.index
        top_groups = self.top_groups
        self._logger.debug('Avoid to recommend pgs with few sales')
        top_groups_values = self.top_groups_values.drop(columns=["PeerGroupId"])
        self.top_groups_recommend = top_groups[top_groups_values > self.minimum_recommendation_ranking_value].fillna(self.recommendation_not_valid) # Exclude recommendations with too low value.
        self.top_groups_recommend = self.top_groups_recommend.drop(columns=["PeerGroupId"])

        sales_data_dfs = []

        if "5-1" in self.rules:
            self._logger.info('Start calculate 5-1 ...')
            sales_data_dfs.append(pd.concat(data.apply(lambda row:self.__recommendy_x(row,1,5),axis=1).values.tolist()))

        if "n_unsold_groups" in self.rules:
            for n in range(1,self.maximum_unsold_n+1,1): # Perform recommendation from 1 on to limit.
                self._logger.info('Start calculate '+str(n)+' best unsold ...')
                sales_data_dfs.append(pd.concat(data.apply(lambda row:self.__recommend_n_best_unsold(row,n),axis=1).values.tolist()))

        if "highest_potential" in self.rules:
            self._logger.info('Start calculate highest potential ...')
            sales_data_dfs.append(pd.concat(data.apply(lambda row:self.__highest_potential(row),axis=1).values.tolist()))

        self.sales_data = pd.concat(sales_data_dfs)

        self._logger.debug('Number of impossible recommendations due to failing coditions:'+str(len(self.sales_data[self.sales_data["SaraProductGroup"]==self.no_recomendation])))
        self.sales_data = self.sales_data[self.sales_data["SaraProductGroup"]!=self.no_recomendation]
        self._logger.debug('Number of not valid recommendations:'+str(len(self.sales_data[self.sales_data["SaraProductGroup"]==self.recommendation_not_valid])))
        self.sales_data = self.sales_data[self.sales_data["SaraProductGroup"]!=self.recommendation_not_valid]
        self.recommendation_data = self.sales_data.reset_index().drop("index",axis=1)
        self._logger.debug('droping CustomerId from dataframe')
        self.data = self.data.drop("CustomerId",axis=1)
        self.__calculate_recommendation_details()
       

    def perform_peer_group_clustering(self,dataframe):
        """ Perform peer group clustering.

        Args:
            dataframe (pandas.DataFrame): Data frame with one row per customer and one column per product group with the row index being the customer number.
        """
        self._logger.info('Load data ...')
        self.data = dataframe
        self._logger.info('Start clustering ...')
        self._logger.info('input data size: %d', len(self.data))
        self.__cluster_data()
        self.__select_customers()
        self._logger.info('Clustering finished.')

    def calculate_recommendations(self):
        """ Calculate recommendations.
        """
        #if "cluster_labels" not in self.__dict__:
        #    self._logger.exception('Cannot calculate recommendations: Cluster labels are missing. Please run perform_peer_group_clustering()')
        self._logger.info('Start calculate recommendations ...')
        self.__calculate_top_groups()
        self.__recommend_groups()
        self._logger.info('Finished recommendations calculation')

    def list_groups_in_cluster(self):
        """ Calculate data frame discibing the top groups per cluster.
        """
        self._logger.info('Start calculate groups in clusters ...')
        #if "cluster_labels" not in self.__dict__:
        #    self._logger.exception('Cannot calculate recommendations: Cluster labels are missing. Please run perform_peer_group_clustering()')
        self.__calculate_top_groups()

    def collect_customer_cluster_mapping(self):
        """ Create dataframe for mapping peer group and customer numbers.
        """
        self._logger.info('Start calculate customer-cluster mapping ...')
        data = self.data
        #data["CustomerId"]= data.index
        #customer_cluster_mapping = data[["CustomerId","PeerGroupId"]]
        customer_cluster_mapping = data[["PeerGroupId"]]
        all_customer_together = pd.DataFrame({"CustomerId":self.all_customers,"delete":self.all_customers}) # .astype(str)
        self.customer_cluster_mapping = customer_cluster_mapping.merge(all_customer_together,how="outer", left_index=True, right_on="CustomerId").drop("delete",axis=1)
        # self.data = self.data.drop("CustomerId",axis=1)
        self.customer_cluster_mapping["PeerGroupId"] = self.customer_cluster_mapping["PeerGroupId"].fillna(999).astype(int).astype(str)
        



if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    #logger = get_logger(__name__)
    import yaml
    config_dict = yaml.load(open("C:/work/SARA/SARA.MVP/Solution Items/Config/sara.yaml"))
    df_abs = pd.read_pickle("C:/Users/asinger/OneDrive - IT Vision Technology GmbH/Projects/Sara/DataPickle/df_abs.p")
    df_abs.index = df_abs["customernumber"].astype(str)
    df_abs = df_abs.drop("customernumber",axis=1)
    recommend_Sara = SaraRecommendations(config_dict)
    recommend_Sara.perform_peer_group_clustering(df_abs)
    recommend_Sara.rules = ["5-1","highest_potential","n_unsold_groups"]
    recommend_Sara.maximum_unsold_n = 5
    recommend_Sara.calculate_recommendations()
    recommend_Sara.list_groups_in_cluster()
    recommend_Sara.collect_customer_cluster_mapping()