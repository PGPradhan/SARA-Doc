import pandas as pd
import time
import sqlalchemy
from sqlalchemy.sql import text

import modules.utils as utils
from modules.LoggingHelper import get_logger

class DataDetailsObject(utils.JsonSerializable):
    '''Data container class holding simple values - to be serialized to JSON'''
    def __init__(self):
        '''dynamically add attributes/member variables to instance of this class that need to be serialized to JSON'''
        pass


class DatabaseManager():

    def __init__(self, config):
        self._config = config
        self.result_id = None
        self._db_schema = self._config["database"]["schema"]
        self._logger = get_logger()

    def _create_db_engine(self, mode="odbc"):
        if mode == "odbc":
            return self._create_db_engine_pyodbc()
        else:
            return self._create_db_engine_pymssql()


    def _create_db_engine_pymssql(self):
        self._logger.debug("create db engine - use pymssql")
        db_config = self._config["database"]
        if "database.windows.net" in db_config["server"]:
            db_username = "{}@{}".format(db_config["user"], db_config["server"].split('.')[0])
        else: 
            db_username = db_config["user"]

        connection_string = "mssql+pymssql://{}:{}@{}/{}".format(
            db_username,
            db_config["password"], 
            db_config["server"], 
            db_config["dbname"])
        self._logger.debug("Connectionstring: " + connection_string)
        engine = sqlalchemy.create_engine(connection_string, echo=False)
        self._logger.debug("db engine created.")
        return engine


    def _create_db_engine_pyodbc(self):
        self._logger.debug("create db engine - use pyodbc")
        db_config = self._config["database"]

        driver = db_config.get("driver", "{ODBC Driver 17 for SQL Server}")
        password = db_config["password"]
        
        connection_params = f"Driver={driver};Server=tcp:{db_config['server']},1433;Database={db_config['dbname']};Uid={db_config['user']};Pwd={password};Encrypt=yes;TrustServerCertificate=yes;Connection Timeout=30;"
        connection_string = f"mssql+pyodbc:///?odbc_connect={connection_params}"
        self._logger.debug("Connectionstring: " + connection_string.replace(password, password[0] + "***" + password[-1]))
        engine = sqlalchemy.create_engine(connection_string, echo=False)
        self._logger.debug("db engine created.")
        return engine


    def create_result_record(self, model_version):
        '''Create the initial/master result record and retrieve its ID, which is required by foreign-key dependent tables (_write_db_table_XYZ)'''
        engine = self._create_db_engine()
        self._logger.info("Create/open result record, model_version=" + model_version)
        with engine.begin() as conn:  # ContextManager handles transaction
            sql_query = "insert into [{}].[Results] (ModelVersion, StartTimeUtc) OUTPUT inserted.ResultId values ('{}', GETUTCDATE())".format(self._db_schema, model_version)	
            self._logger.info("Execute sql query: " + sql_query)
            data_row = conn.execute(text(sql_query)).fetchone()
            self.result_id = int(data_row[0])

            self._logger.info("Created result record.")
            self._logger.debug("id=" + str(self.result_id))


    def quote_Nonable_for_db(self, value):
        if value is None:
            return 'Null'
        else:
            return "'{}'".format(value)


    def close_result_record(self, result_status, result_details=None, error_details=None):
        if self.result_id is None:
            self._logger.error("Cannot close result record: ResultId is not available.")
            return 

        engine = self._create_db_engine()
        self._logger.info("Close result record")
        with engine.begin() as conn:  # begin uses ContextManager which handles transaction
            sql_query = "update [{}].[Results] set ResultStatus='{}', EndTimeUtc=GETUTCDATE(), ResultDetailsJson={}, ErrorDetailsJson={} where ResultId={}".format(self._db_schema, result_status, self.quote_Nonable_for_db(result_details), self.quote_Nonable_for_db(error_details), self.result_id)
            self._logger.info("Execute sql query: " + sql_query[0:100] + "...")
            conn.execute(text(sql_query))
            self._logger.info("Close/update result table")


    def _truncate_db_table(self, table_name):
        self._logger.info("Truncate DB table: %s", table_name)
        engine = self._create_db_engine()
        with engine.begin() as conn:  # begin uses ContextManager which handles transaction
            # sql_query = "truncate table [{}].[{}]".format(self._db_schema, table_name)

            # Truncate is faster but requires excessive permissions. Use delete instead, although significantly slower
            sql_query = "delete from [{}].[{}]".format(self._db_schema, table_name)
            self._logger.info("Execute sql query: " + sql_query[0:100] + "...")
            conn.execute(text(sql_query))
            self._logger.info("DB table %s truncated successfully.", table_name)


    def get_latest_model_version(self, model_version_base):
        '''query database for models with same date'''
        self._logger.info("Get previous model versions (same base model)")
        engine = self._create_db_engine()
        sql_query = "Select ModelVersion from [{}].[Results] where ModelVersion like '{}.%' order by ModelVersion desc".format(self._db_schema, model_version_base)
        self._logger.debug("connect")
        with engine.connect() as conn:  
            self._logger.debug("execute query: %s", sql_query)
            latest_model_version = conn.execute(text(sql_query)).fetchone()
            if latest_model_version is not None:
                latest_model_version = str(latest_model_version[0])
            self._logger.info("Got latest model version: ")
            self._logger.info(latest_model_version)
        return latest_model_version


    def _read_db_table(self, sql_query:str) -> pd.DataFrame:  
        '''
            Read data from database table
            @sql_query: sql query string - does not support query parameters
        '''
        engine = self._create_db_engine()
        with engine.connect() as conn:
            self._logger.debug("execute query: %s", sql_query)
            df = pd.read_sql_query(sql_query, conn) 
        self._logger.debug("Fetch complete, #records: %d", len(df))
        return df


    def read_db_salesorderitems(self) -> pd.DataFrame:
        table_name_with_schema = f"[{self._db_schema}].[CrmSalesOrderItems]"
        self._logger.info(f"read sales items from database table '{table_name_with_schema}'")
        sql_query = f"SELECT [SalesOrderDateTime], [CustomerId], [ProductId], [NetValue] from {table_name_with_schema}"
        df_salesorderitems = self._read_db_table(sql_query)
        self._logger.info("Fetch complete, #salesorderitems: %d", len(df_salesorderitems))
        return df_salesorderitems


    def read_product_mappings(self) -> pd.DataFrame:
        table_name_with_schema = f"[{self._db_schema}].[CrmProducthierarchy]"
        self._logger.info(f"read product mappings from database table '{table_name_with_schema}'")
        df_product_mappings = self._read_db_table(f"SELECT * from {table_name_with_schema}") 
        self._logger.info("Fetch complete, #productmappings: %d", len(df_product_mappings))
        return df_product_mappings


    def _write_db_table(self, db_tablename, dataframe):
        try:
            self._logger.info("write db table")
            chunksize = self._config["database"].get("chunksize", 1000)

            start_time = time.time()
            df_extended = dataframe.copy()
            df_extended["ResultId"] = [self.result_id] * len(dataframe)  # add foreign-key reference

            engine = self._create_db_engine()
            self._logger.info("Begin transaction")
            with engine.begin() as conn:  # begin uses ContextManager which handles transaction
                self._logger.info("Write dataframe to db table: " + db_tablename)
                df_extended.to_sql(db_tablename, conn, schema=self._db_schema, index=False, if_exists='append', chunksize=chunksize)
            self._logger.info("Table written to database, duration={}s".format(round(time.time()-start_time, 1)))
        except Exception:
            self._logger.exception("Failed to write database table: %s", db_tablename)


    def write_db_table_peergroups(self, dataframe) :
        self._write_db_table("PeerGroups", dataframe)

    def write_db_table_peergroupproductgroups(self, dataframe) :
        self._write_db_table("PeerGroupProductGroups", dataframe)

    def write_db_table_recommendations(self, dataframe) :
        self._write_db_table("RecommendationCandidates", dataframe)

    def write_db_table_customerproductgroupsellings(self, dataframe) :
        self._write_db_table("CustomerProductGroupSellings", dataframe)

    def truncate_db_table_recommendations(self) :
        self._truncate_db_table("RecommendationCandidates")
