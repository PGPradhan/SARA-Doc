import os
import sys
import pandas as pd

from modules.LoggingHelper import get_logger


class ProductGroupMappings() :

    def __init__(self, config):
        self._config = config
        self._logger = get_logger()
        self._log_data = self._logger.debug

        # raw tables as from Excel
        self._df_raw_prd_pg_map = None
        self._df_raw_sara_map = None

        # processed tables
        self.df_prd_spg_map = None
        self.df_spg_displaytext_map = None



    def _load_raw_producthierarchy_mapping(self):
        ''' 
            load the product hierarchy mapping of the entire tk MX product inventory.
            The mapping is shipped as a set of excel files, since it is not yet contained in CRM.
            The files provide a mapping of a product/product identifier to a product hiearchy string
            which contains the required level-3 product group identifier
        '''
        self._logger.info("load product hierarchy files")
        data_path = self._config["static"]["path"]
        data_files = self._config["static"]["prd_pg_map"]  # list, data is split in several Excel files
        i = 0
        for data_file in data_files:
            data_file = os.path.join(data_path, data_file)
            self._logger.info("load product hierarchy file: " + data_file)
            df_part = pd.read_excel(data_file, index_col=0)
            self._logger.debug("partial data, count=%d", len(df_part))
            if i == 0:
                self._df_raw_prd_pg_map = df_part
            else:
                self._logger.info("append data")
                self._df_raw_prd_pg_map = self._df_raw_prd_pg_map.append(df_part)
            i = i + 1

        self._logger.info("all partial files loaded, total count=%d", len(self._df_raw_prd_pg_map))

        # Exctract level-3 ProductGroup identifier from Produkthiearchie string: charcter positions 4 to 10
        self._df_raw_prd_pg_map["ProductGroup"] = [ph[4:11] for ph in self._df_raw_prd_pg_map.Produkthierarchie.values]
        self._df_raw_prd_pg_map.reset_index(inplace=True)
        self._df_raw_prd_pg_map.rename(columns={"Material" : "ProductId"}, inplace=True)
        self._df_raw_prd_pg_map = self._df_raw_prd_pg_map[["ProductId", "ProductGroup"]] # strip unnecessary parts
        self._logger.info("post processing completed")
        self._logger.info("load product hierarchy completed")



    def _load_raw_sara_productgroup_mapping(self):
        ''' 
            load the manually crafted mapping of level-3 product group to the actual sara product group.
        '''
        self._logger.info("load SARA product group mapping")
        data_path = self._config["static"]["path"]
        data_file = self._config["static"]["pg_spg_map"] 
        data_file = os.path.join(data_path, data_file)
        self._logger.info("load SARA product group mapping: " + data_file)

        #
        # NOTE: empty Excel cells are converted to string 'nan' after import !
        #
        try:
            self._df_raw_sara_map = pd.read_excel(data_file, sheet_name=2, usecols="A,F,G") # 3rd sheet
        except:
            self._df_raw_sara_map = pd.read_excel(data_file, sheetname=2, parse_cols="A,F,G") # 3rd sheet

        self._df_raw_sara_map = self._df_raw_sara_map.astype(str) # force to str, otherwise empty cells are treated as float 
        self._log_data(self._df_raw_sara_map.head())

        self._df_raw_sara_map.columns.values[0] = "SaraProductGroupName"
        self._df_raw_sara_map.columns.values[1] = "SaraProductGroup"
        self._df_raw_sara_map.drop("Schlüssel", inplace=True) # this is an unnecessary 2nd header row in the Excel document 
        self._df_raw_sara_map.reset_index(inplace=True)
        self._log_data(self._df_raw_sara_map.head())

        self._df_raw_sara_map.rename(columns={"index" : "ProductGroup"}, inplace=True)
        self._df_raw_sara_map = self._df_raw_sara_map[["ProductGroup", "SaraProductGroup", "SaraProductGroupName"]]
        self._logger.info("Sara productgroup mapping: %d lines read", len(self._df_raw_sara_map))
        self._log_data(self._df_raw_sara_map.describe())

        self._logger.info("Filter out deactivated SARA product groups")
        deactivation_filter_criteria = (self._df_raw_sara_map["SaraProductGroup"].str.len() < 2) | (self._df_raw_sara_map["SaraProductGroup"].str == "nan") | (self._df_raw_sara_map["SaraProductGroupName"].str.len() <= 1)
        df_filtered_entries = self._df_raw_sara_map[deactivation_filter_criteria]
        self._logger.info("The following {} ProductGroups are de-selected for clustering: {}".format(len(df_filtered_entries), df_filtered_entries["ProductGroup"].values.tolist()))
        self._df_raw_sara_map = self._df_raw_sara_map[~deactivation_filter_criteria]
        self._logger.info("Sara final productgroup mapping: %d lines.", len(self._df_raw_sara_map))


        self._logger.info("load SARA product group mapping completed.")



    def _write_csv_file(self, dataframe, config_key_name):
        config_node = self._config["auxtables"]
        data_path = config_node["path"]
        if not os.path.exists(data_path):
            os.makedirs(data_path, exist_ok=True)

        filename = os.path.join(data_path, config_node[config_key_name])        
        dataframe.to_csv(filename, encoding="utf-8")
        self._logger.info("CSV file written to: " + filename)


    def _create_product_to_sara_mapping(self):
        self._logger.info("create product to SARA product group mapping")

        if self._df_raw_prd_pg_map is None:
            self._load_raw_producthierarchy_mapping()
        if self._df_raw_sara_map is None:
            self._load_raw_sara_productgroup_mapping()

        self.df_prd_spg_map = self._df_raw_prd_pg_map.merge(self._df_raw_sara_map, on="ProductGroup", how="left")
        self._logger.info("Merge complete, len={}".format(len(self.df_prd_spg_map)))

        self._write_csv_file(self.df_prd_spg_map, "prd_spg_map")
        self._logger.info("Write product to SARA product group mappings completed.")


    def _create_sara_displaytext_mapping(self):
        self._logger.info("create mapping for SARA product group to the display text")

        if self._df_raw_sara_map is None:
            self._load_raw_sara_productgroup_mapping()

        self.df_spg_displaytext_map = self._df_raw_sara_map[["SaraProductGroup", "SaraProductGroupName"]]
        self.df_spg_displaytext_map.drop_duplicates(inplace=True)

        # check for duplicate key entries
        saraProductGroups = self.df_spg_displaytext_map["SaraProductGroup"]
        duplicates = saraProductGroups[saraProductGroups.duplicated()]
        if duplicates is not None and len(duplicates) > 0:
            self._logger.warn("Dupliate entries found in Sara product groups mapping table:")
            self._logger.warn(duplicates)

        self.df_spg_displaytext_map.set_index('SaraProductGroup', inplace=True)
        self._logger.info("Merge complete, len={}".format(len(self.df_spg_displaytext_map)))
        self._log_data(self.df_spg_displaytext_map.head())

        self._write_csv_file(self.df_spg_displaytext_map, "spg_display_map")
        self._logger.info("Write SARA product group display text mappings completed.")
    

    def _get_auxtables_filename(self, config_key_name):
        data_path = self._config["auxtables"]["path"]
        data_file = self._config["auxtables"][config_key_name]  
        return os.path.join(data_path, data_file)

    def _load_or_create_product_to_sara_mapping(self):
        self._logger.info("load product to SARA product group mapping")

        data_file = self._get_auxtables_filename("prd_spg_map")
        if not os.path.exists(data_file):
            self._create_product_to_sara_mapping()
        else:
            self._logger.info("Loading product to SARA product group mapping: " + data_file)
            self.df_prd_spg_map = pd.read_csv(data_file, encoding="utf-8")

        self._log_data(self.df_prd_spg_map.head())
        self._logger.info("Loading product to SARA product group mapping completed.")


    def _load_or_create_sara_displaytext_mapping(self):
        self._logger.info("Load SARA product group to displaytext mapping")

        data_file = self._get_auxtables_filename("spg_display_map")
        if not os.path.exists(data_file):
            self._create_sara_displaytext_mapping()
        else:
            self._logger.info("Loading product to SARA product group mapping: " + data_file)
            self.df_spg_displaytext_map = pd.read_csv(data_file, encoding="utf-8", index_col=0)

        self._log_data(self.df_spg_displaytext_map.head())
        self._logger.info("Load SARA product group to displaytext mapping completed.")


    def create_auxiliary_tables(self):
        self._logger.info("create auxiliary tables")
        self._create_product_to_sara_mapping()
        self._create_sara_displaytext_mapping()


    def load_or_create_auxiliary_tables(self):
        self._load_or_create_product_to_sara_mapping()
        self._load_or_create_sara_displaytext_mapping()


if __name__ == "__main__":
    create_product_to_sara_mapping(sys.argv[1])     # update product to sara product group mapping




