import sys
import os
import yaml
import logging
from logging.handlers import TimedRotatingFileHandler

# Azure Monitoring / Applications Insights
from opentelemetry._logs import (get_logger_provider, set_logger_provider)
from opentelemetry.sdk._logs import (LoggerProvider, LoggingHandler)
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from azure.monitor.opentelemetry.exporter import AzureMonitorLogExporter

DATA_LEVEL_NUM = 5
FALLBACK_LOG = './fatal.log'

_LOGGER = None


def data(self, message, *args, **kws):
    # Yes, logger takes its '*args' as 'args'.
    if self.isEnabledFor(DATA_LEVEL_NUM):
        self._log(DATA_LEVEL_NUM, "", args, **kws) 
        self._log(DATA_LEVEL_NUM, message, args, **kws) 
        self._log(DATA_LEVEL_NUM, "", args, **kws) 


def add_data_level():
    logging.addLevelName(DATA_LEVEL_NUM, "DATA")
    logging.Logger.data = data
    logging.data = data
    logging.DATA = DATA_LEVEL_NUM

def clean_old_fallback_logs():
    try:
        if os.path.exists(FALLBACK_LOG):
            os.remove(FALLBACK_LOG)
    except:
        pass

def init_fallback_logging():
    try:
        print("failed to initialize regular logging")
        add_data_level()
        #logging_format = '%(asctime)s %(levelname)-8s %(module)-25s %(message)s'
        logging.basicConfig(filename=FALLBACK_LOG, level=logging.DEBUG, format=LevelFormatter.default_logging_format, filemode='w') # overwrite
        logging.info("Could not initialize regular log. Using fallback log %s instead.", FALLBACK_LOG)
    except:
        pass


def _create_azure_monitoring_handler(appinsights_connection_string:str, run_id:str):
    '''
        Init logger for Azure Application Insights / Azure Monitor
    '''
    set_logger_provider(LoggerProvider())
    exporter = AzureMonitorLogExporter(connection_string=appinsights_connection_string)
    get_logger_provider().add_log_record_processor(BatchLogRecordProcessor(exporter))

    handler = LoggingHandler()
    return handler


def init_logging(yaml_config_file:str, application:str, run_id:str):
    '''
        Init logging and set global logger instance containing extra data
    '''
    global _LOGGER
    clean_old_fallback_logs()

    try:
        with open(yaml_config_file, "r") as fp:
            log_config = yaml.safe_load(fp)["logging"]

        log_path = log_config["path"]
        log_file = os.path.join(log_path, log_config["logfile"])    
        log_level_str = log_config["loglevel"].upper()
        log_level = logging.getLevelName(log_level_str) # undocumented feature of this method

        if not os.path.exists(log_path):
            os.mkdir(log_path)

        add_data_level()

        logging.getLogger().setLevel(logging.INFO)

        # create the main logger
        logger = logging.getLogger(__name__)
        logger.info("LOG_LEVEL=[%r], %r", log_level, logger.getEffectiveLevel())

        # handler: log to console
        console = logging.StreamHandler(sys.stdout)
        console.setLevel(log_level)

        # handler: log to file
        file_handler = TimedRotatingFileHandler(log_file, when="midnight", backupCount=log_config["max_roll_backups"])
        file_handler.setLevel(log_level)

        # handler: log to Azure Monitoring / Application Insights
        azure_handler = _create_azure_monitoring_handler(log_config["appinsights_connectionstring"], run_id)
        azure_handler.setLevel(logging.INFO) # fixed to INFO

        # add handlers to main logger
        for handler in [console, file_handler, azure_handler]:
            handler.setFormatter(LevelFormatter())
            logger.addHandler(handler)

        # add extra tags to logs
        logger = logging.LoggerAdapter(logger, extra={"application": application, "run_id": run_id})
        logger.info("logging initialized.") # log always

        # store logger with extra data
        _LOGGER = logger
    except:
        print(sys.exc_info())
        init_fallback_logging()


def get_logger() -> logging.Logger:
    ''' 
        Provide the central logging instance, which includes mandatory extra data
        ** Use this function instead of logging.getLogger() in all code **
    '''
    return _LOGGER


def load_log_file(config):
    try:
        log_file = os.path.join(config["logging"]["path"], config["logging"]["logfile"])    
        with open(log_file, "r") as fp:
            log_content = fp.read()
        return log_content
    except:
        return ""


class LevelFormatter(logging.Formatter):
    
    default_logging_format = '%(asctime)s %(levelname)8s %(module)-25s %(funcName)-25s  %(message)s'
    default_formatter = logging.Formatter(default_logging_format)
    data_formatter = logging.Formatter(r'%(message)s')

    def format(self, record):
        if record.levelno >= 100: # always
            return self.data_formatter.format(record)
        elif record.levelno == logging.DATA:
            return self.data_formatter.format(record)
        else:
            return self.default_formatter.format(record)